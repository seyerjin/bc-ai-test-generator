# Changelog

All notable changes to the "AL AI Test Generator" extension will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-02-14

### Added
- 🎉 Initial release of AL AI Test Generator
- 🤖 AI-powered test generation using Claude API (Anthropic)
- 🔒 Secure API key management via VS Code Secret Storage
- 📊 Comprehensive telemetry service for scientific evaluation
- 🎯 Support for AL (Business Central) code analysis
- ⚡ Single file and batch processing for multiple AL files
- 🧪 Generation of comprehensive test codeunits with Given-When-Then pattern
- 📈 Real-time metrics collection for DSR methodology
- 🔧 Configurable test complexity levels (basic, intermediate, comprehensive)
- 🎭 Mock implementation generation for dependencies
- 🔄 Integration test support alongside unit tests
- 📋 Command palette integration with all major functions
- 🎨 Context menu integration for AL files in Explorer and Editor
- 📊 Scientific metrics export for research purposes
- 🛡️ Robust error handling and input validation
- 📖 Comprehensive documentation for academic use

### Features
#### Core Functionality
- **Test Generation**: Intelligent AL test code generation with Claude AI
- **Code Analysis**: Static analysis of AL files for procedure detection
- **Batch Processing**: Generate combined tests for multiple selected files
- **Configuration Management**: Secure storage and management of API keys

#### Scientific Features
- **Metrics Collection**: Real-time collection of DSR evaluation metrics
- **Export Functionality**: JSON export of research data
- **Performance Tracking**: Generation time, success rate, and productivity metrics
- **Coverage Analysis**: Code coverage estimation and tracking

#### Security & Privacy
- **Secret Storage**: VS Code Secret Storage API integration
- **Migration Support**: Automatic migration from insecure to secure storage
- **Anonymization**: Privacy-first telemetry collection
- **Opt-out Support**: User-controlled telemetry enable/disable

#### Developer Experience
- **VS Code Integration**: Native extension with proper command registration
- **Progress Indicators**: Real-time progress feedback during generation
- **Error Reporting**: Detailed error messages and troubleshooting
- **Status Management**: Visual status bar updates

### Technical Details
- **Target Platform**: Visual Studio Code ^1.74.0
- **Language Support**: AL (Microsoft Dynamics 365 Business Central)
- **AI Provider**: Anthropic Claude API
- **Storage**: VS Code Secret Storage for API keys
- **Telemetry**: Anonymous data collection for research

### Commands Added
- `alAiTestGen.generateTests` - Generate AI tests for single AL file
- `alAiTestGen.generateCombinedTests` - Generate combined tests for multiple files
- `alAiTestGen.configure` - Configure Claude API key securely
- `alAiTestGen.showMetrics` - Display scientific metrics summary
- `alAiTestGen.exportMetrics` - Export research data to JSON
- `alAiTestGen.clearMetrics` - Clear all telemetry data
- `alAiTestGen.removeApiKey` - Remove stored API key

### Settings Added
- `alAiTestGen.testFramework` - Test framework selection (AL Test Framework)
- `alAiTestGen.testComplexity` - Test complexity level
- `alAiTestGen.generateMocks` - Enable/disable mock generation
- `alAiTestGen.maxTestsPerFile` - Maximum tests per file limit
- `alAiTestGen.includeIntegrationTests` - Include integration tests
- `alAiTestGen.includePerformanceTests` - Include performance tests
- `alAiTestGen.enableTelemetry` - Enable scientific data collection

### Scientific Contribution
This release represents the implementation phase of a Master's thesis in Cloud Computing at Hochschule Burgenland, applying Design Science Research (DSR) methodology to address challenges in ERP test automation.

#### Research Metrics Implemented
- **Metric 1**: Test creation time (manual vs. AI-generated)
- **Metric 2**: Productivity (tests per hour)
- **Metric 3**: Personnel effort (developer hours)
- **Metric 4**: Code coverage percentage
- **Metric 5**: Error detection rate

#### Academic Validation
- Empirical data collection for scientific evaluation
- Anonymous telemetry respecting research ethics
- Export functionality for statistical analysis
- Baseline establishment for future research

### Known Issues
- API rate limits may affect batch processing of large file sets
- Generated tests may require manual refinement for specific business logic
- Performance may vary based on file complexity and API response times
- Limited to AL language support (Business Central only)

### Dependencies
- `@anthropic-ai/sdk`: ^0.24.3 - Claude API integration
- `@types/vscode`: ^1.74.0 - VS Code extension types
- Various development dependencies for TypeScript compilation and testing

---

## Roadmap

### Planned for v1.1.0
- Performance optimizations for large file processing
- Enhanced error messages and troubleshooting guides
- Additional test patterns and frameworks
- Improved caching mechanisms

### Future Versions
- Support for additional ERP languages (C/AL, X++)
- Integration with other AI providers
- Advanced team collaboration features
- Enterprise licensing and management tools

---

## Contributing

This extension is part of academic research. Contributions are welcome through:
- Bug reports with detailed reproduction steps
- Feature requests aligned with research objectives
- Documentation improvements
- Testing in various Business Central environments

See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines.

## Academic Citation

```
Seyer, M. (2025). AL AI Test Generator v1.0.0: KI-gestützte Testfallgenerierung 
für Microsoft Dynamics 365 Business Central [Computer software]. 
Hochschule Burgenland. https://github.com/matthias-seyer/al-ai-test-generator
```