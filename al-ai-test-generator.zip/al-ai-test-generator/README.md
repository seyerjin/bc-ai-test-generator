# AL AI Test Generator

Eine VSCode-Extension für die automatisierte Generierung von Microsoft Dynamics 365 Business Central Test Codeunits mittels Künstlicher Intelligenz, entwickelt nach den offiziellen Microsoft-Teststandards.

## 📋 Überblick

Diese Extension wurde als Teil einer Masterarbeit im Studienfach Cloud Computing entwickelt und implementiert die automatisierte Testfallgenerierung für Microsoft Dynamics 365 Business Central unter strikter Einhaltung der Microsoft-Dokumentation für Test Codeunits.

## 🎯 Microsoft-konforme Implementierung

Die Extension folgt exakt den offiziellen Microsoft Learn-Richtlinien:
- [Test Codeunits and Test Methods](https://learn.microsoft.com/en-us/dynamics365/business-central/dev-itpro/developer/devenv-test-codeunits-and-test-methods)
- [Test Runner Codeunits](https://learn.microsoft.com/en-us/dynamics365/business-central/dev-itpro/developer/devenv-testrunner-codeunits)

### ✅ Implementierte Microsoft-Standards

#### Test Codeunit-Struktur
- **SubType = Test** - Korrekte Codeunit-Deklaration
- **TestPermissions = Disabled** - Standard-Berechtigungseinstellung
- **TestIsolation = Codeunit** - Transaktionsisolation nach Best Practices

#### Test-Attribute
- `[Test]` - Für Test-Methoden
- `[TestSetup]` - Für Setup-Methoden
- `[TestTeardown]` - Für Cleanup-Methoden
- `[Handler]` - Für UI-Handler
- `[TransactionModel(TransactionModel::AutoRollback)]` - Für Integrationstests

#### AL Test Framework-Integration
- **Library Assert** - Verwendung offizieller Assert-Methoden
- **Library Test Initialize** - Standardisierte Test-Initialisierung
- **Given-When-Then-Pattern** - Strukturierte Testorganisation

#### Transaktionsmodelle
- AutoRollback für sichere Testausführung
- Proper Setup/Teardown-Mechanismen
- Isolation zwischen Testmethoden

## 🚀 Features

### Kern-Funktionalitäten
- **Einzeldatei-Tests**: Generierung von Test Codeunits für einzelne AL-Dateien
- **Kombinierte Tests**: Zusammenfassung mehrerer AL-Dateien in einer Test Codeunit
- **Git-Integration**: Automatische Benennung basierend auf Git-Branch
- **Microsoft-konforme Ausgabe**: Alle generierten Tests folgen den offiziellen Standards

### Test-Generierung
- **Positive Tests**: Gültige Eingabeszenarien
- **Negative Tests**: Fehlerbehandlung mit `asserterror`
- **Boundary Tests**: Edge-Case-Abdeckung
- **Integration Tests**: Transaktionsbasierte Tests
- **Mock-Generierung**: Automatische Test-Daten-Setup

### Entwicklerfreundlich
- **IntelliSense**: Code-Snippets für AL-Tests
- **Status-Anzeige**: Fortschrittsanzeige in der Statusleiste
- **Konfigurierbar**: Umfangreiche Einstellungsmöglichkeiten
- **Cache-System**: Optimierte Performance

## 📦 Installation

1. Clone das Repository
2. Installiere Abhängigkeiten: `npm install`
3. Kompiliere die Extension: `npm run compile`
4. Starte in VSCode: `F5`

## ⚙️ Konfiguration

### Claude API-Schlüssel
1. Führe `AL: Configure AI Test Generator` aus
2. Gib deinen Claude API-Schlüssel ein
3. Der Schlüssel wird sicher in VSCode gespeichert

### Test-Einstellungen
```json
{
  "alAiTestGen.testComplexity": "comprehensive",
  "alAiTestGen.generateMocks": true,
  "alAiTestGen.includeIntegrationTests": true,
  "alAiTestGen.testIsolation": "Codeunit",
  "alAiTestGen.transactionModel": "AutoRollback"
}
```

## 📖 Verwendung

### Einzelne Datei testen
1. Rechtsklick auf eine .al-Datei
2. Wähle "AL: Generate AI Test Codeunit"
3. Test Codeunit wird im `/test`-Verzeichnis erstellt

### Mehrere Dateien kombinieren
1. Markiere mehrere .al-Dateien
2. Rechtsklick → "AL: Generate Combined Test Codeunit for Selected Files"
3. Kombinierte Test Codeunit wird generiert

### Befehle
- `AL: Generate AI Test Codeunit` - Einzeldatei-Test
- `AL: Generate Combined Test Codeunit for Selected Files` - Kombinierte Tests
- `AL: Configure AI Test Generator` - Konfiguration
- `AL: Run Generated Tests` - Test-Ausführung
- `AL: Create Test Suite` - Test Suite-Erstellung

## 🏗️ Architektur

### Service-Layer
- **TestGenerator**: Microsoft-konforme Test-Generierung
- **ClaudeService**: AI-Integration mit Rate-Limiting
- **ALAnalyzer**: AL-Code-Analyse und -Parsing

### Utility-Layer
- **FileManager**: Datei-Operationen und Test-Erstellung
- **ConfigurationManager**: Sichere Konfigurationsverwaltung
- **GitHelper**: Git-Integration für intelligente Benennung
- **StatusBarManager**: Benutzer-Feedback

## 📋 Generierte Test-Struktur

```al
/// <summary>
/// AI-generated test codeunit for Codeunit 50000 "Sample Logic"
/// Generated following Microsoft Dynamics 365 Business Central test standards
/// Framework: AL Test Framework
/// </summary>
codeunit 59000 "Test Sample Logic"
{
    Subtype = Test;
    TestPermissions = Disabled;
    TestIsolation = Codeunit;
    
    var
        LibraryAssert: Codeunit "Library Assert";
        LibraryTestInitialize: Codeunit "Library - Test Initialize";
        IsInitialized: Boolean;

    [TestSetup]
    procedure TestSetup()
    begin
        LibraryTestInitialize.OnTestInitialize(CODEUNIT::"Test Sample Logic");
        if IsInitialized then
            exit;
        
        // Global setup for all tests
        IsInitialized := true;
        Commit();
    end;

    [Test]
    procedure TestCalculateAmount_WithValidInput_ReturnsCorrectValue()
    begin
        // Given
        
        // When
        
        // Then
        LibraryAssert.AreEqual(ExpectedValue, ActualValue, 'Error message');
    end;
}
```

## 🧪 Test-Best-Practices

### Microsoft-Standards
- Verwendung von Library Assert für alle Validierungen
- Given-When-Then-Struktur für Lesbarkeit
- Meaningful Testmethoden-Namen
- Proper Setup/Teardown-Implementierung

### Naming Conventions
- `TestMethodName_Scenario_ExpectedResult`
- Beispiel: `TestCalculateAmount_WithValidInput_ReturnsCorrectValue`

### Error Testing
```al
[Test]
procedure TestDivision_WithZeroDivisor_ThrowsError()
begin
    // Given
    // Setup data with zero divisor
    
    // When & Then
    asserterror Division(10, 0);
    LibraryAssert.IsTrue(StrPos(GetLastErrorText(), 'Division by zero') > 0, 'Wrong error message');
end;
```

## 🔧 Entwicklung

### Build-Prozess
```bash
npm run compile          # Kompilierung
npm run watch           # Watch-Modus
npm run package         # Produktions-Build
npm run test            # Tests ausführen
```

### Debugging
1. Setze Breakpoints in TypeScript-Code
2. Drücke `F5` für Debug-Session
3. Teste die Extension in neuer VSCode-Instanz

## 📚 Wissenschaftliche Grundlage

Diese Extension wurde im Rahmen einer Masterarbeit entwickelt, die sich mit der automatisierten Testfallgenerierung für ERP-Systeme beschäftigt. Die Implementierung basiert auf:

- **Design Science Research (DSR)** Methodologie
- **Microsoft Learn** Dokumentation für Business Central
- **AL Test Framework** Best Practices
- **Continuous Integration/Continuous Deployment** Integration

## 🤝 Beitrag zur Wissenschaft

Die Extension trägt zur Forschung in folgenden Bereichen bei:
- **ERP-Testautomatisierung** in Microsoft Dynamics 365
- **KI-gestützte Code-Generierung** für Unternehmenssoftware
- **CI/CD-Integration** in AL-Entwicklungsprozessen

## 📄 Lizenz

MIT License - Siehe [LICENSE](LICENSE) Datei für Details.

## 🔗 Verwandte Ressourcen

- [Microsoft Learn - AL Test Framework](https://learn.microsoft.com/en-us/dynamics365/business-central/dev-itpro/developer/devenv-test-codeunits-and-test-methods)
- [Business Central Development Documentation](https://learn.microsoft.com/en-us/dynamics365/business-central/dev-itpro/)
- [AL Language Extension for VSCode](https://marketplace.visualstudio.com/items?itemName=ms-dynamics-smb.al)

---

**Entwickelt für die Masterarbeit "Automatisierte Testfallgenerierung für Microsoft Dynamics 365 Business Central mittels Künstlicher Intelligenz"**
**Fachhochschule Burgenland, Cloud Computing**