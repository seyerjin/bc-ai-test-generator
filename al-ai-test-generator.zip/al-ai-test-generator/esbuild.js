const { build, context } = require("esbuild");

const production = process.argv.includes('--production');
const watch = process.argv.includes('--watch');

/**
 * @type {import('esbuild').Plugin}
 */
const esbuildProblemMatcherPlugin = {
  name: 'esbuild-problem-matcher',
  setup(build) {
    build.onStart(() => {
      console.log('[watch] build started');
    });
    build.onEnd((result) => {
      result.errors.forEach(({ text, location }) => {
        console.error(`✘ [ERROR] ${text}`);
        if (location) {
          console.error(`    ${location.file}:${location.line}:${location.column}:`);
        }
      });
      console.log('[watch] build finished');
    });
  },
};

const buildOptions = {
  entryPoints: [
    'src/extension.ts'
  ],
  bundle: true,
  format: 'cjs',
  minify: production,
  sourcemap: !production,
  sourcesContent: false,
  platform: 'node',
  outfile: 'dist/extension.js',
  external: ['vscode'],
  logLevel: 'silent',
  plugins: [
    esbuildProblemMatcherPlugin,
  ],
  define: {
    'process.env.NODE_ENV': production ? '"production"' : '"development"'
  },
  keepNames: true,
  metafile: production,
};

async function main() {
  try {
    if (watch) {
      // Watch mode - use context
      const ctx = await context(buildOptions);
      await ctx.watch();
      console.log('[watch] watching for changes...');
      
      // Keep process alive
      process.on('SIGINT', async () => {
        console.log('\n[watch] stopping...');
        await ctx.dispose();
        process.exit(0);
      });
    } else {
      // One-time build
      const result = await build(buildOptions);
      
      if (result.errors.length > 0) {
        console.error('Build failed with errors:');
        result.errors.forEach(error => console.error(error));
        process.exit(1);
      }
      
      if (result.warnings.length > 0) {
        console.warn('Build completed with warnings:');
        result.warnings.forEach(warning => console.warn(warning));
      }
      
      console.log('Build completed successfully!');
    }
  } catch (error) {
    console.error('Build error:', error);
    process.exit(1);
  }
}

main();