# 🚀 Installation der AL AI Test Generator Extension

## 📋 Schritt-für-Schritt Anleitung

### 1️⃣ **Projekt aufsetzen**

```bash
# Neues Verzeichnis erstellen
mkdir al-ai-test-generator
cd al-ai-test-generator

# Alle Dateien aus den Artifacts kopieren (siehe unten)
```

### 2️⃣ **Obligatorische Dateien kopieren**

Kopieren Sie **alle** folgenden Dateien aus den Artifacts:

#### 📁 **Root-Verzeichnis:**
- `package.json` (korrigierte Version)
- `tsconfig.json`
- `esbuild.js` (korrigierte Version)
- `.gitignore`
- `.eslintignore`
- `.eslintrc.json`
- `README.md`

#### 📁 **src/services/:**
- `ALAnalyzer.ts` (korrigierte Version)
- `ClaudeService.ts` 
- `TestGenerator.ts` (korrigierte Version)

#### 📁 **src/utils/:**
- `ConfigurationManager.ts` (korrigierte Version)
- `FileManager.ts`
- `StatusBarManager.ts`
- `GitHelper.ts`

#### 📁 **src/:**
- `extension.ts`

#### 📁 **.vscode/:**
- `launch.json`

### 3️⃣ **Dependencies installieren**

```bash
# Node modules installieren
npm install

# TypeScript global installieren (falls nicht vorhanden)
npm install -g typescript

# VS Code Extension CLI installieren (optional)
npm install -g @vscode/vsce
```

### 4️⃣ **TelemetryService.ts Problem lösen**

Falls Sie eine `TelemetryService.ts` Datei haben, die **nicht** Teil dieser Extension ist:

```bash
# Option A: Datei löschen (falls nicht benötigt)
rm src/utils/TelemetryService.ts

# Option B: In .eslintignore ist bereits eingetragen
# Die Datei wird ignoriert und verursacht keine Probleme mehr
```

### 5️⃣ **Kompilieren und testen**

```bash
# Linting und Build
npm run lint:fix
npm run compile

# Erfolgsmeldung sollte erscheinen:
# "Build completed successfully!"
```

### 6️⃣ **Extension in VS Code testen**

```bash
# VS Code öffnen
code .

# F5 drücken für Debug-Session
# Neue VS Code Instanz öffnet sich mit der Extension
```

### 7️⃣ **Claude API Key konfigurieren**

1. **Claude API Key besorgen:**
   - Gehen Sie zu [console.anthropic.com](https://console.anthropic.com/)
   - Account erstellen/einloggen
   - API Key generieren

2. **In Extension konfigurieren:**
   ```
   Cmd/Ctrl + Shift + P
   → "AL: Configure AI Test Generator"
   → API Key eingeben
   ```

### 8️⃣ **Erste Tests generieren**

1. **AL-Datei erstellen oder öffnen**
2. **Rechtsklick auf .al Datei**
3. **"AL: Generate AI Test Codeunit" auswählen**

## ⚠️ **Häufige Probleme lösen**

### **ESLint Warnings:**
```bash
npm run lint:fix
```

### **Build Fehler:**
```bash
# Clean build
npm run clean
npm install
npm run compile
```

### **Extension startet nicht:**
- Claude API Key konfiguriert?
- Alle Dateien korrekt kopiert?
- VS Code neu starten

### **TypeScript Fehler:**
```bash
# Type checking
npm run check-types
```

## 📦 **Extension packen (optional)**

```bash
# .vsix Datei erstellen
npm run package:vsix

# Extension installieren
code --install-extension al-ai-test-generator-1.0.0.vsix
```

## 🎯 **Erfolgskriterien**

✅ **`npm run compile` läuft ohne Fehler**  
✅ **F5 startet neue VS Code Instanz**  
✅ **Extension erscheint in Extensions List**  
✅ **Commands sind im Command Palette verfügbar**  
✅ **Rechtsklick auf .al Datei zeigt Test-Generation**

## 🆘 **Support**

Falls Probleme auftreten:
1. **Alle korrigierten Dateien nochmal kopieren**
2. **`npm install` und `npm run compile` wiederholen**
3. **Projekt-Repository überprüfen**

---

**Die Extension ist jetzt bereit für Ihre Masterarbeit! 🎓**