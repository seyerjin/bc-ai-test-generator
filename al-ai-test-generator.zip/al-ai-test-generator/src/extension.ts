import * as vscode from 'vscode';
import * as path from 'path';
import { ClaudeService } from './services/ClaudeService';
import { ALAnalyzer } from './services/ALAnalyzer';
import { TestGenerator } from './services/TestGenerator';
import { ConfigurationManager } from './utils/ConfigurationManager';
import { FileManager } from './utils/FileManager';
import { StatusBarManager } from './utils/StatusBarManager';
import { GitHelper } from './utils/GitHelper';

let statusBar: StatusBarManager;

export function activate(context: vscode.ExtensionContext) {
    console.log('AL AI Test Generator is now active!');
    
    // Initialize status bar
    statusBar = new StatusBarManager();
    context.subscriptions.push(statusBar);
    
    // Initialize services
    const configManager = new ConfigurationManager(context);
    const claudeService = new ClaudeService(configManager);
    const alAnalyzer = new ALAnalyzer();
    const testGenerator = new TestGenerator(claudeService, alAnalyzer);
    const fileManager = new FileManager();
    const gitHelper = new GitHelper();

    // Register command: Generate tests for single file
    const generateTestsCommand = vscode.commands.registerCommand(
        'alAiTestGen.generateTests',
        async (uri?: vscode.Uri) => {
            try {
                // Check API key configuration first
                if (!await ensureApiKeyConfigured(configManager, claudeService)) {
                    return;
                }

                statusBar.showProgress('Generating AI test codeunit');
                
                const fileUri = uri || vscode.window.activeTextEditor?.document.uri;
                if (!fileUri) {
                    vscode.window.showErrorMessage('Please select an AL file');
                    return;
                }

                if (!fileUri.path.endsWith('.al')) {
                    vscode.window.showWarningMessage('Please select an AL file');
                    return;
                }

                // Generate test codeunit for single file
                await generateCombinedTestsForFiles([fileUri], testGenerator, fileManager, gitHelper);
                
                statusBar.showSuccess('Finished');
                vscode.window.showInformationMessage('Test codeunit generated successfully!');
            } catch (error: any) {
                statusBar.showError('Test generation failed');
                vscode.window.showErrorMessage(`Test generation failed: ${error.message}`);
                console.error('Test generation error:', error);
            }
        }
    );

    // Register command: Generate combined tests for selected files
    const generateCombinedTestsCommand = vscode.commands.registerCommand(
        'alAiTestGen.generateCombinedTests',
        async (uri?: vscode.Uri, selectedFiles?: vscode.Uri[]) => {
            try {
                // Check API key configuration first
                if (!await ensureApiKeyConfigured(configManager, claudeService)) {
                    return;
                }

                statusBar.showProgress('Generating combined AI test codeunit');
                
                // Get selected files
                const files = selectedFiles || (uri ? [uri] : []);
                if (files.length === 0) {
                    vscode.window.showErrorMessage('Please select one or more AL files');
                    return;
                }

                // Filter only AL files
                const alFiles = files.filter(f => f.path.endsWith('.al'));
                if (alFiles.length === 0) {
                    vscode.window.showWarningMessage('Please select AL files');
                    return;
                }

                // Generate combined tests
                await generateCombinedTestsForFiles(alFiles, testGenerator, fileManager, gitHelper);
                
                statusBar.showSuccess('Finished');
                vscode.window.showInformationMessage('Combined test codeunit generated successfully!');
            } catch (error: any) {
                statusBar.showError('Test generation failed');
                vscode.window.showErrorMessage(`Test generation failed: ${error.message}`);
                console.error('Test generation error:', error);
            }
        }
    );

    // Register configure command
    const configureCommand = vscode.commands.registerCommand(
        'alAiTestGen.configure',
        async () => {
            await configureApiKey(configManager, claudeService);
        }
    );

    context.subscriptions.push(
        generateTestsCommand,
        generateCombinedTestsCommand,
        configureCommand
    );

    // Show welcome message on first activation
    if (configManager.isFirstActivation()) {
        showWelcomeMessage(configManager);
    }
}

async function generateCombinedTestsForFiles(
    uris: vscode.Uri[],
    testGenerator: TestGenerator,
    fileManager: FileManager,
    gitHelper: GitHelper
): Promise<void> {
    await vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: "AL AI Test Generator",
        cancellable: true
    }, async (progress, token) => {
        progress.report({ increment: 0, message: "Analyzing AL files..." });
        statusBar.showProgress('Analyzing AL files');
        
        // Analyze all selected files
        const analyses = [];
        const fileNames = [];
        
        for (const uri of uris) {
            const document = await vscode.workspace.openTextDocument(uri);
            const alCode = document.getText();
            const analysis = await testGenerator.analyzeCode(alCode);
            analyses.push(analysis);
            fileNames.push(path.basename(uri.fsPath, '.al'));
        }
        
        if (token.isCancellationRequested) {
            throw new Error('Operation cancelled');
        }
        
        progress.report({ increment: 30, message: "Generating test cases..." });
        statusBar.showProgress('Generating test cases');
        
        // Get git branch name for naming
        const branchName = await gitHelper.getCurrentBranch();
        const testCodeunitName = branchName 
            ? `Combined Tests for ${branchName}`
            : `Combined Tests for ${fileNames.join(', ')}`;
        
        // Generate combined test codeunit
        const testCode = await testGenerator.generateCombinedTests(
            analyses, 
            testCodeunitName,
            {
                includeIntegrationTests: true,
                includeMocks: true,
                includePerformanceTests: false,
                testComplexity: 'comprehensive',
                maxTestsPerProcedure: 5
            },
            token
        );
        
        progress.report({ increment: 80, message: "Creating test file..." });
        statusBar.showProgress('Creating test file');
        
        // Create test file
        const testFileUri = await fileManager.createCombinedTestFile(uris[0], testCode, testCodeunitName);
        
        progress.report({ increment: 95, message: "Opening test file..." });
        statusBar.showProgress('Opening test file');
        
        const testDocument = await vscode.workspace.openTextDocument(testFileUri);
        await vscode.window.showTextDocument(testDocument, { preview: false });
        
        progress.report({ increment: 100 });
    });
}

function showWelcomeMessage(configManager: ConfigurationManager): void {
    vscode.window.showInformationMessage(
        'Welcome to the AL-AI-Test-Generator',
        'Please configure your API key',
        'Later'
    ).then(selection => {
        if (selection === 'Please configure your API key') {
            configureApiKey(configManager, null);
        }
    });
}

async function configureApiKey(configManager: ConfigurationManager, claudeService: ClaudeService | null): Promise<void> {
    const configured = await configManager.configure();
    
    if (configured && claudeService) {
        // Test the API key connection
        statusBar.showProgress('Testing API connection');
        
        try {
            const isValid = await claudeService.testConnection();
            if (isValid) {
                statusBar.showSuccess('Connection successful');
                vscode.window.showInformationMessage('Connection successful - happy testing');
            } else {
                statusBar.showError('Connection failed');
                vscode.window.showErrorMessage('API key test failed. Please check your API key.');
            }
        } catch (error: any) {
            statusBar.showError('Connection failed');
            vscode.window.showErrorMessage(`Connection test failed: ${error.message}`);
        }
    }
}

async function ensureApiKeyConfigured(configManager: ConfigurationManager, claudeService: ClaudeService): Promise<boolean> {
    const apiKey = await configManager.getApiKey();
    
    if (!apiKey) {
        const choice = await vscode.window.showWarningMessage(
            'Please configure your API key',
            'Configure Now',
            'Cancel'
        );
        
        if (choice === 'Configure Now') {
            await configureApiKey(configManager, claudeService);
            // Check again if key was configured
            const newApiKey = await configManager.getApiKey();
            return !!newApiKey;
        }
        return false;
    }
    
    return true;
}

export function deactivate() {
    console.log('AL AI Test Generator deactivated');
}