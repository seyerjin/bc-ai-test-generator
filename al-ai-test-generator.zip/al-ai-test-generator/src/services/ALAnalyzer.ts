export interface ALProcedure {
    name: string;
    parameters: ALParameter[];
    returnType?: string;
    isLocal: boolean;
    visibility: 'Public' | 'Internal' | 'Local';
}

export interface ALParameter {
    name: string;
    type: string;
    isVar: boolean;
}

export interface ALField {
    id: number;
    name: string;
    type: string;
    hasConstraints?: boolean;
    minValue?: number;
    maxValue?: number;
}

export interface BusinessContext {
    domain: string;
    dataFlow: string[];
    businessRules: string[];
    integrationPoints: string[];
}

export interface TestScenario {
    type: string;
    description: string;
    priority: 'Low' | 'Medium' | 'High';
}

export interface TestStrategy {
    objectName: string;
    approach: string;
    testTypes: string[];
    setupRequirements: string[];
}

export interface ALCodeAnalysis {
    objectType: string;
    objectName: string;
    objectId: number;
    procedures: ALProcedure[];
    fields: ALField[];
    complexity: 'Low' | 'Medium' | 'High';
    dependencies: string[];
    businessContext?: BusinessContext;
    testableScenarios?: TestScenario[];
}

export class ALAnalyzer {
    analyzeCode(alCode: string): ALCodeAnalysis {
        const analysis: ALCodeAnalysis = {
            objectType: this.extractObjectType(alCode),
            objectName: this.extractObjectName(alCode),
            objectId: this.extractObjectId(alCode),
            procedures: this.extractProcedures(alCode),
            fields: this.extractFields(alCode),
            complexity: this.calculateComplexity(alCode),
            dependencies: this.extractDependencies(alCode),
            businessContext: this.analyzeBusinessContext(alCode),
            testableScenarios: this.identifyTestableScenarios(alCode)
        };
        
        return analysis;
    }

    async generateTestingStrategy(analysis: ALCodeAnalysis): Promise<TestStrategy> {
        return {
            objectName: analysis.objectName,
            approach: this.determineTestingApproach(analysis),
            testTypes: this.identifyTestTypes(analysis),
            setupRequirements: this.determineSetupRequirements(analysis)
        };
    }

    extractObjectType(alCode: string): string {
        const typeMatch = alCode.match(/^\s*(table|page|codeunit|report|xmlport|query|enum|interface|tableextension|pageextension|reportextension|enumextension|profile|controladdins)\s+/mi);
        return typeMatch ? typeMatch[1] : 'Unknown';
    }

    extractObjectName(alCode: string): string {
        const nameMatch = alCode.match(/^\s*\w+\s+\d+\s+"([^"]+)"/m);
        return nameMatch ? nameMatch[1] : 'Unknown';
    }

    extractObjectId(alCode: string): number {
        const idMatch = alCode.match(/^\s*\w+\s+(\d+)/m);
        return idMatch ? parseInt(idMatch[1]) : 0;
    }

    private extractProcedures(alCode: string): ALProcedure[] {
        const procedures: ALProcedure[] = [];
        const regex = /(?:local\s+)?procedure\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)(?:\s*:\s*([^;{]+))?/gmi;
        let match;

        while ((match = regex.exec(alCode)) !== null) {
            const isLocal = match[0].toLowerCase().includes('local');
            const parameters = this.parseParameters(match[2]);
            
            procedures.push({
                name: match[1],
                parameters: parameters,
                returnType: match[3]?.trim(),
                isLocal: isLocal,
                visibility: isLocal ? 'Local' : 'Public'
            });
        }

        return procedures;
    }

    private parseParameters(paramString: string): ALParameter[] {
        if (!paramString.trim()) return [];

        const parameters: ALParameter[] = [];
        const params = paramString.split(';');

        for (const param of params) {
            const trimmedParam = param.trim();
            if (!trimmedParam) continue;

            const varMatch = trimmedParam.match(/^(var\s+)?(.+?):\s*(.+)$/);
            if (varMatch) {
                const paramNames = varMatch[2].split(',').map(name => name.trim());
                const paramType = varMatch[3].trim();
                const isVar = !!varMatch[1];

                for (const paramName of paramNames) {
                    parameters.push({
                        name: paramName,
                        type: paramType,
                        isVar: isVar
                    });
                }
            }
        }

        return parameters;
    }

    private extractFields(alCode: string): ALField[] {
        const fields: ALField[] = [];
        const regex = /field\s*\(\s*(\d+)\s*;\s*"?([^";]+)"?\s*;\s*([^)]+)\)\s*\{([^}]*)\}/gmi;
        let match;

        while ((match = regex.exec(alCode)) !== null) {
            const fieldId = parseInt(match[1]);
            const fieldName = match[2].trim();
            const fieldType = match[3].trim();
            const fieldProperties = match[4];

            // Extract constraints from field properties
            const minValueMatch = fieldProperties.match(/MinValue\s*=\s*(\d+)/i);
            const maxValueMatch = fieldProperties.match(/MaxValue\s*=\s*(\d+)/i);

            fields.push({
                id: fieldId,
                name: fieldName,
                type: fieldType,
                hasConstraints: !!(minValueMatch || maxValueMatch),
                minValue: minValueMatch ? parseInt(minValueMatch[1]) : undefined,
                maxValue: maxValueMatch ? parseInt(maxValueMatch[1]) : undefined
            });
        }

        return fields;
    }

    private calculateComplexity(alCode: string): 'Low' | 'Medium' | 'High' {
        const procedureCount = (alCode.match(/procedure\s+/gi) || []).length;
        const ifCount = (alCode.match(/\bif\b/gi) || []).length;
        const caseCount = (alCode.match(/\bcase\b/gi) || []).length;
        const loopCount = (alCode.match(/\b(for|while|repeat)\b/gi) || []).length;
        const fieldCount = (alCode.match(/field\s*\(/gi) || []).length;

        const complexityScore = procedureCount + (ifCount * 2) + (caseCount * 3) + (loopCount * 3) + fieldCount;

        if (complexityScore < 20) return 'Low';
        if (complexityScore < 50) return 'Medium';
        return 'High';
    }

    private extractDependencies(alCode: string): string[] {
        const dependencies = new Set<string>();
        
        // Extract record dependencies
        const recordRegex = /:\s*Record\s+"?([^";]+)"?/gi;
        let match;
        while ((match = recordRegex.exec(alCode)) !== null) {
            dependencies.add(`Record: ${match[1]}`);
        }

        // Extract codeunit dependencies  
        const codeunitRegex = /:\s*Codeunit\s+"?([^";]+)"?/gi;
        while ((match = codeunitRegex.exec(alCode)) !== null) {
            dependencies.add(`Codeunit: ${match[1]}`);
        }

        // Extract page dependencies
        const pageRegex = /:\s*Page\s+"?([^";]+)"?/gi;
        while ((match = pageRegex.exec(alCode)) !== null) {
            dependencies.add(`Page: ${match[1]}`);
        }

        // Extract report dependencies
        const reportRegex = /:\s*Report\s+"?([^";]+)"?/gi;
        while ((match = reportRegex.exec(alCode)) !== null) {
            dependencies.add(`Report: ${match[1]}`);
        }

        return Array.from(dependencies);
    }

    private analyzeBusinessContext(alCode: string): BusinessContext {
        const context: BusinessContext = {
            domain: this.identifyDomain(alCode),
            dataFlow: this.analyzeDataFlow(alCode),
            businessRules: this.extractBusinessRules(alCode),
            integrationPoints: this.findIntegrationPoints(alCode)
        };
        
        return context;
    }

    private identifyDomain(alCode: string): string {
        const salesKeywords = ['customer', 'sales', 'invoice', 'order', 'quote', 'shipment'];
        const purchaseKeywords = ['vendor', 'purchase', 'receipt', 'payable', 'purchase order'];
        const financeKeywords = ['gl', 'ledger', 'account', 'balance', 'financial', 'posting', 'credit', 'debit'];
        const inventoryKeywords = ['item', 'inventory', 'stock', 'warehouse', 'location', 'bin'];
        const hrKeywords = ['employee', 'payroll', 'hr', 'human resources'];
        const manufactKeywords = ['production', 'bom', 'routing', 'manufacturing'];
        
        const lowerCode = alCode.toLowerCase();
        
        if (salesKeywords.some(keyword => lowerCode.includes(keyword))) return 'Sales';
        if (purchaseKeywords.some(keyword => lowerCode.includes(keyword))) return 'Purchase';
        if (financeKeywords.some(keyword => lowerCode.includes(keyword))) return 'Finance';
        if (inventoryKeywords.some(keyword => lowerCode.includes(keyword))) return 'Inventory';
        if (hrKeywords.some(keyword => lowerCode.includes(keyword))) return 'HumanResources';
        if (manufactKeywords.some(keyword => lowerCode.includes(keyword))) return 'Manufacturing';
        
        return 'General';
    }

    private analyzeDataFlow(alCode: string): string[] {
        const dataFlow: string[] = [];
        
        // Find data retrieval patterns
        if (alCode.match(/\.get\s*\(/gi)) {
            dataFlow.push('Data Retrieval');
        }
        
        // Find data modification patterns
        if (alCode.match(/\.(insert|modify|delete)\s*\(/gi)) {
            dataFlow.push('Data Modification');
        }
        
        // Find calculation patterns
        if (alCode.match(/[+\-*/]\s*\w+|:=.*[+\-*/]/gi)) {
            dataFlow.push('Calculations');
        }
        
        // Find validation patterns
        if (alCode.match(/if\s+.*\s+then\s+error/gi)) {
            dataFlow.push('Validation');
        }
        
        return dataFlow;
    }

    private extractBusinessRules(alCode: string): string[] {
        const businessRules: string[] = [];
        
        // Extract validation rules
        const errorStatements = alCode.match(/error\s*\(\s*['"][^'"]*['"]/gi);
        if (errorStatements) {
            errorStatements.forEach(statement => {
                const message = statement.match(/['"]([^'"]*)['"]/);
                if (message) {
                    businessRules.push(`Validation: ${message[1]}`);
                }
            });
        }
        
        // Extract field constraints
        const minValueRules = alCode.match(/MinValue\s*=\s*\d+/gi);
        const maxValueRules = alCode.match(/MaxValue\s*=\s*\d+/gi);
        
        if (minValueRules) {
            businessRules.push(`Field Constraints: Minimum values defined`);
        }
        if (maxValueRules) {
            businessRules.push(`Field Constraints: Maximum values defined`);
        }
        
        return businessRules;
    }

    private findIntegrationPoints(alCode: string): string[] {
        const integrationPoints: string[] = [];
        
        // Find external codeunit calls
        const codeunitCalls = alCode.match(/\w+\.\w+\s*\(/gi);
        if (codeunitCalls) {
            integrationPoints.push('External Codeunit Integration');
        }
        
        // Find web service patterns
        if (alCode.match(/xmlport|webservice|httpclient/gi)) {
            integrationPoints.push('Web Service Integration');
        }
        
        // Find event patterns
        if (alCode.match(/\[Event.*Subscriber\]/gi)) {
            integrationPoints.push('Event Integration');
        }
        
        return integrationPoints;
    }

    private identifyTestableScenarios(alCode: string): TestScenario[] {
        const scenarios: TestScenario[] = [];
        
        // Identify calculation scenarios
        const calculations = alCode.match(/(\w+)\s*:=\s*[^;]+[+\-*/]/g);
        if (calculations) {
            scenarios.push({
                type: 'Calculation',
                description: 'Test mathematical operations and formulas',
                priority: 'High'
            });
        }
        
        // Identify validation scenarios
        const validations = alCode.match(/if\s+.*\s+then\s+error/gi);
        if (validations) {
            scenarios.push({
                type: 'Validation',
                description: 'Test data validation and error conditions',
                priority: 'High'
            });
        }
        
        // Identify data modification scenarios
        const modifications = alCode.match(/\.(insert|modify|delete)\s*\(/gi);
        if (modifications) {
            scenarios.push({
                type: 'DataModification',
                description: 'Test data creation, updates, and deletion',
                priority: 'Medium'
            });
        }
        
        // Identify boundary value scenarios
        const boundaryValues = alCode.match(/(MinValue|MaxValue)\s*=\s*\d+/gi);
        if (boundaryValues) {
            scenarios.push({
                type: 'BoundaryValue',
                description: 'Test field boundary values and constraints',
                priority: 'High'
            });
        }
        
        // Identify integration scenarios
        const integrations = alCode.match(/\w+\.\w+\s*\(/gi);
        if (integrations) {
            scenarios.push({
                type: 'Integration',
                description: 'Test integration with external components',
                priority: 'Medium'
            });
        }
        
        return scenarios;
    }

    private determineTestingApproach(analysis: ALCodeAnalysis): string {
        switch (analysis.objectType.toLowerCase()) {
            case 'tableextension':
                return 'Field validation and business logic testing with base table integration';
            case 'codeunit':
                return 'Procedure isolation with dependency mocking and comprehensive unit testing';
            case 'page':
            case 'pageextension':
                return 'UI interaction testing with field validation and action verification';
            case 'report':
                return 'Data processing and output validation testing';
            default:
                return 'Comprehensive functional testing with appropriate mocking strategy';
        }
    }

    private identifyTestTypes(analysis: ALCodeAnalysis): string[] {
        const testTypes: string[] = ['UnitTest'];
        
        if (analysis.fields && analysis.fields.length > 0) {
            testTypes.push('FieldValidation');
        }
        
        if (analysis.procedures.some(p => p.name.toLowerCase().includes('calculate'))) {
            testTypes.push('CalculationTest');
        }
        
        if (analysis.businessContext?.businessRules.length || 0 > 0) {
            testTypes.push('BusinessRuleTest');
        }
        
        if (analysis.dependencies.length > 0) {
            testTypes.push('IntegrationTest');
        }
        
        if (analysis.testableScenarios?.some(s => s.type === 'BoundaryValue')) {
            testTypes.push('BoundaryValueTest');
        }
        
        return testTypes;
    }

    private determineSetupRequirements(analysis: ALCodeAnalysis): string[] {
        const requirements: string[] = [];
        
        // Base requirements
        requirements.push('Initialize test environment');
        
        // Object-specific requirements
        switch (analysis.objectType.toLowerCase()) {
            case 'tableextension':
                requirements.push(`Create base ${this.getBaseTableName(analysis)} records`);
                requirements.push('Setup extended field test data');
                break;
                
            case 'codeunit':
                requirements.push('Mock external dependencies');
                requirements.push('Setup test data for procedures');
                break;
                
            case 'page':
            case 'pageextension':
                requirements.push('Mock page interactions');
                requirements.push('Setup UI test data');
                break;
        }
        
        // Domain-specific requirements
        if (analysis.businessContext) {
            switch (analysis.businessContext.domain) {
                case 'Sales':
                    requirements.push('Use Library - Sales for test data creation');
                    break;
                case 'Purchase':
                    requirements.push('Use Library - Purchase for test data creation');
                    break;
                case 'Finance':
                    requirements.push('Use Library - Finance for test data creation');
                    break;
                case 'Inventory':
                    requirements.push('Use Library - Inventory for test data creation');
                    break;
            }
        }
        
        return requirements;
    }

    private getBaseTableName(analysis: ALCodeAnalysis): string {
        // Extract base table name from extension
        const match = analysis.objectName.match(/(\w+)\s+(Ext|Extension)/i);
        return match ? match[1] : 'Record';
    }
}