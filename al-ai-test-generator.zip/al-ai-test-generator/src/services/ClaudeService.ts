import Anthropic from '@anthropic-ai/sdk';
import * as vscode from 'vscode';
import { ConfigurationManager } from '../utils/ConfigurationManager';
import PQueue from 'p-queue';

export interface TestGenerationOptions {
    includeIntegrationTests: boolean;
    includeMocks: boolean;
    includePerformanceTests: boolean;
    testComplexity: 'basic' | 'comprehensive' | 'exhaustive';
    maxTestsPerProcedure: number;
}

interface CachedResponse {
    testCode: string;
    timestamp: number;
}

export class ClaudeService {
    private client: Anthropic | null = null;
    private queue: PQueue;
    private cache = new Map<string, CachedResponse>();
    private readonly CACHE_TTL = 3600000; // 1 hour

    constructor(private configManager: ConfigurationManager) {
        this.queue = new PQueue({ 
            concurrency: 5,
            interval: 60000,
            intervalCap: 50
        });
        
        this.initializeClient();
    }

    private async initializeClient(): Promise<void> {
        const apiKey = await this.configManager.getApiKey();
        if (apiKey) {
            this.client = new Anthropic({
                apiKey: apiKey,
                maxRetries: 3
            });
        }
    }

    /**
     * Test the API connection with the configured API key
     * @returns Promise<boolean> - true if connection successful
     */
    async testConnection(): Promise<boolean> {
        try {
            // Reinitialize client with current API key
            await this.initializeClient();
            
            if (!this.client) {
                return false;
            }

            // Send a minimal test request to verify the API key
            const response = await this.client.messages.create({
                model: 'claude-3-haiku-20240307', // Use faster model for testing
                max_tokens: 10,
                temperature: 0,
                messages: [{
                    role: 'user',
                    content: 'Test'
                }]
            });

            return response && response.content && response.content.length > 0;
        } catch (error: any) {
            console.error('API connection test failed:', error);
            
            // Handle specific error types
            if (error.status === 401) {
                throw new Error('Invalid API key. Please check your Claude API key.');
            } else if (error.status === 429) {
                throw new Error('Rate limit exceeded. Please try again later.');
            } else if (error.status === 400) {
                throw new Error('Bad request. Please check your API key format.');
            } else {
                throw new Error(`Connection failed: ${error.message || 'Unknown error'}`);
            }
        }
    }

    async generateTests(
        codeAnalysis: any,
        options: TestGenerationOptions,
        cancellationToken?: vscode.CancellationToken
    ): Promise<string> {
        if (!this.client) {
            const configured = await this.configManager.configure();
            if (!configured) {
                throw new Error('Claude API key not configured');
            }
            await this.initializeClient();
        }

        const cacheKey = this.getCacheKey(codeAnalysis, options);
        const cached = this.cache.get(cacheKey);
        
        // Check if cache is valid
        if (cached && (Date.now() - cached.timestamp < this.CACHE_TTL)) {
            return cached.testCode;
        }

        // Use queue.add with proper return type
        const testCode = await this.queue.add(async () => {
            if (cancellationToken?.isCancellationRequested) {
                throw new Error('Operation cancelled');
            }

            const prompt = this.buildPrompt(codeAnalysis, options);
            
            try {
                const response = await this.client!.messages.create({
                    model: 'claude-sonnet-4-20250514',
                    max_tokens: 4000,
                    temperature: 0.1,
                    system: this.getSystemPrompt(),
                    messages: [{
                        role: 'user',
                        content: prompt
                    }]
                });

                const generatedCode = response.content[0].type === 'text' 
                    ? response.content[0].text 
                    : '';
                    
                // Cache with timestamp
                this.cache.set(cacheKey, {
                    testCode: generatedCode,
                    timestamp: Date.now()
                });
                
                return generatedCode;
            } catch (error: any) {
                if (error.status === 429) {
                    await new Promise(resolve => setTimeout(resolve, 5000));
                    return this.generateTests(codeAnalysis, options, cancellationToken);
                }
                throw error;
            }
        });

        return testCode || '';
    }

    private buildPrompt(analysis: any, options: TestGenerationOptions): string {
        return `
Generate comprehensive AL test cases for Microsoft Dynamics 365 Business Central.

## Object Details
- Type: ${analysis.objectType}
- Name: ${analysis.objectName}
- ID: ${analysis.objectId}
- Complexity: ${analysis.complexity}

## Procedures to Test
${analysis.procedures.map((p: any) => 
    `- ${p.name}(${p.parameters.map((param: any) => 
        `${param.name}: ${param.type}`).join(', ')}): ${p.returnType || 'void'}`
).join('\n')}

## Test Requirements
- Framework: AL Test Framework
- Test Complexity: ${options.testComplexity}
- Include Integration Tests: ${options.includeIntegrationTests}
- Include Mocks: ${options.includeMocks}
- Include Performance Tests: ${options.includePerformanceTests}
- Max Tests Per Procedure: ${options.maxTestsPerProcedure}

## Instructions
1. Create a complete test codeunit with proper AL syntax
2. Include [Test] procedures for all public methods
3. Add [TestSetup] and [TestTeardown] procedures
4. Use Library Assert for validations
5. Follow Given-When-Then naming pattern
6. Include ASSERTERROR for negative test cases
7. Generate mock implementations if requested
8. Ensure all code compiles without errors

Output only the complete AL test codeunit code, no markdown or explanations.`;
    }

    private getSystemPrompt(): string {
        return `You are an expert AL developer for Microsoft Dynamics 365 Business Central with extensive experience in test automation. 

Generate production-ready AL test code following these principles:
- Use official AL Test Framework patterns
- Include comprehensive test coverage
- Follow Business Central best practices
- Write clear, maintainable test code
- Use proper AL syntax and conventions
- Include meaningful test descriptions
- Handle all edge cases and error scenarios`;
    }

    private getCacheKey(analysis: any, options: TestGenerationOptions): string {
        return `${analysis.objectType}_${analysis.objectName}_${JSON.stringify(options)}`;
    }

    clearCache(): void {
        this.cache.clear();
    }
}