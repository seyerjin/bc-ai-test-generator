// import * as Handlebars from 'handlebars';
import { ALCodeAnalysis, ALProcedure, ALField } from './ALAnalyzer';

export interface TestTemplateContext {
    objectType: string;
    objectName: string;
    objectId: number;
    testCodeunitId: number;
    testCodeunitName: string;
    featureDescription: string;
    libraryVariables: string[];
    procedures: ProcedureTestContext[];
    fields: FieldTestContext[];
    integrationScenarios: IntegrationScenario[];
    dataCreationHelpers: DataCreationHelper[];
    initializationCode: string;
    cleanupCode: string;
}

export interface ProcedureTestContext {
    name: string;
    pascalCase: string;
    parameters: string;
    parameterValues: string;
    invalidParameterValues: string;
    returnType?: string;
    isCalculationProcedure: boolean;
    isValidationProcedure: boolean;
    isDataModificationProcedure: boolean;
    hasErrorConditions: boolean;
    localVariables: string;
    setupTestData: string;
    boundaryTestData: string;
    invalidTestData: string;
    boundaryTestExecution: string;
    verificationCode: string;
    expectedErrorMessage: string;
}

export interface FieldTestContext {
    name: string;
    pascalCase: string;
    type: string;
    hasConstraints: boolean;
    validTestValues: any[];
    constraintViolations: ConstraintViolation[];
    baseTableName: string;
    recordVariable: string;
    createRecordInstance: string;
}

export interface ConstraintViolation {
    value: any;
    expectedError: string;
}

export interface IntegrationScenario {
    name: string;
    description: string;
    setup: string;
    execution: string;
    verification: string;
    localVariables: string;
}

export interface DataCreationHelper {
    name: string;
    parameters: string;
    returnType?: string;
    implementation: string;
}

export class TemplateEngine {
    private templateHelpers: Map<string, Function>;

    constructor() {
        this.templateHelpers = new Map();
        this.registerHelpers();
    }

    generateTestCode(analysis: ALCodeAnalysis, testCodeunitId: number, testCodeunitName: string): string {
        const context = this.buildTemplateContext(analysis, testCodeunitId, testCodeunitName);
        return this.processTemplate(this.getALTestTemplate(), context);
    }

    private registerHelpers(): void {
        this.templateHelpers.set('eq', (a: any, b: any) => a === b);
        this.templateHelpers.set('neq', (a: any, b: any) => a !== b);
        this.templateHelpers.set('and', (a: any, b: any) => a && b);
        this.templateHelpers.set('or', (a: any, b: any) => a || b);
        
        this.templateHelpers.set('pascalCase', (str: string) => {
            return str.replace(/\s+/g, '').replace(/^\w/, c => c.toUpperCase());
        });
        
        this.templateHelpers.set('isCalculationProcedure', (name: string) => {
            return name.toLowerCase().includes('calculate') || name.toLowerCase().includes('compute');
        });
        
        this.templateHelpers.set('isValidationProcedure', (name: string) => {
            return name.toLowerCase().includes('validate') || name.toLowerCase().includes('check');
        });
        
        this.templateHelpers.set('isDataModificationProcedure', (name: string) => {
            const lowerName = name.toLowerCase();
            return lowerName.includes('create') || lowerName.includes('update') || 
                   lowerName.includes('modify') || lowerName.includes('delete') ||
                   lowerName.includes('insert');
        });
    }

    private processTemplate(template: string, context: any): string {
        // Simple template processing without Handlebars
        let result = template;
        
        // Replace simple variables
        result = result.replace(/\{\{(\w+)\}\}/g, (match, key) => {
            return context[key] || match;
        });
        
        // Process arrays
        if (context.libraryVariables && Array.isArray(context.libraryVariables)) {
            const libraryVars = context.libraryVariables.join(';\n        ') + ';';
            result = result.replace(/\{\{#each libraryVariables\}\}[\s\S]*?\{\{\/each\}\}/g, libraryVars);
        }
        
        return result;
    }

    private buildTemplateContext(
        analysis: ALCodeAnalysis, 
        testCodeunitId: number, 
        testCodeunitName: string
    ): TestTemplateContext {
        return {
            objectType: analysis.objectType,
            objectName: analysis.objectName,
            objectId: analysis.objectId,
            testCodeunitId: testCodeunitId,
            testCodeunitName: testCodeunitName,
            featureDescription: this.generateFeatureDescription(analysis),
            libraryVariables: this.generateLibraryVariables(analysis),
            procedures: this.buildProcedureContexts(analysis),
            fields: this.buildFieldContexts(analysis),
            integrationScenarios: this.buildIntegrationScenarios(analysis),
            dataCreationHelpers: this.buildDataCreationHelpers(analysis),
            initializationCode: this.generateInitializationCode(analysis),
            cleanupCode: this.generateCleanupCode(analysis)
        };
    }

    private generateFeatureDescription(analysis: ALCodeAnalysis): string {
        const domain = analysis.businessContext?.domain || 'General';
        return `${domain} - ${analysis.objectName} functionality`;
    }

    private generateLibraryVariables(analysis: ALCodeAnalysis): string[] {
        const variables = ['LibraryAssert: Codeunit "Library Assert"'];
        
        const domain = analysis.businessContext?.domain;
        switch (domain) {
            case 'Sales':
                variables.push('LibrarySales: Codeunit "Library - Sales"');
                break;
            case 'Purchase':
                variables.push('LibraryPurchase: Codeunit "Library - Purchase"');
                break;
            case 'Finance':
                variables.push('LibraryFinance: Codeunit "Library - Finance"');
                break;
            case 'Inventory':
                variables.push('LibraryInventory: Codeunit "Library - Inventory"');
                break;
            default:
                variables.push('LibraryUtility: Codeunit "Library - Utility"');
                break;
        }
        
        variables.push('LibraryRandom: Codeunit "Library - Random"');
        
        return variables;
    }

    private buildProcedureContexts(analysis: ALCodeAnalysis): ProcedureTestContext[] {
        return analysis.procedures
            .filter(proc => !proc.isLocal) // Only test public procedures
            .map(proc => this.buildProcedureContext(proc, analysis));
    }

    private buildProcedureContext(procedure: ALProcedure, analysis: ALCodeAnalysis): ProcedureTestContext {
        const isCalculation = this.isCalculationProcedure(procedure.name);
        const isValidation = this.isValidationProcedure(procedure.name);
        const isDataModification = this.isDataModificationProcedure(procedure.name);
        
        return {
            name: procedure.name,
            pascalCase: this.toPascalCase(procedure.name),
            parameters: this.formatParameters(procedure.parameters),
            parameterValues: this.generateParameterValues(procedure.parameters),
            invalidParameterValues: this.generateInvalidParameterValues(procedure.parameters),
            returnType: procedure.returnType,
            isCalculationProcedure: isCalculation,
            isValidationProcedure: isValidation,
            isDataModificationProcedure: isDataModification,
            hasErrorConditions: isValidation || isDataModification,
            localVariables: this.generateLocalVariables(procedure, analysis),
            setupTestData: this.generateSetupTestData(procedure, analysis),
            boundaryTestData: this.generateBoundaryTestData(procedure),
            invalidTestData: this.generateInvalidTestData(procedure),
            boundaryTestExecution: this.generateBoundaryTestExecution(procedure),
            verificationCode: this.generateVerificationCode(procedure, analysis),
            expectedErrorMessage: this.generateExpectedErrorMessage(procedure)
        };
    }

    private buildFieldContexts(analysis: ALCodeAnalysis): FieldTestContext[] {
        if (!analysis.fields) return [];
        
        return analysis.fields.map(field => this.buildFieldContext(field, analysis));
    }

    private buildFieldContext(field: ALField, analysis: ALCodeAnalysis): FieldTestContext {
        const baseTableName = this.getBaseTableName(analysis);
        
        return {
            name: field.name,
            pascalCase: this.toPascalCase(field.name),
            type: field.type,
            hasConstraints: field.hasConstraints || false,
            validTestValues: this.generateValidTestValues(field),
            constraintViolations: this.generateConstraintViolations(field),
            baseTableName: baseTableName,
            recordVariable: this.generateRecordVariableName(baseTableName),
            createRecordInstance: this.generateCreateRecordInstance(baseTableName, analysis)
        };
    }

    private buildIntegrationScenarios(analysis: ALCodeAnalysis): IntegrationScenario[] {
        const scenarios: IntegrationScenario[] = [];
        
        if (analysis.businessContext?.integrationPoints) {
            analysis.businessContext.integrationPoints.forEach(point => {
                scenarios.push({
                    name: this.toPascalCase(point.replace(/\s+/g, '')),
                    description: `Integration with ${point}`,
                    setup: this.generateIntegrationSetup(point, analysis),
                    execution: this.generateIntegrationExecution(point, analysis),
                    verification: this.generateIntegrationVerification(point),
                    localVariables: this.generateIntegrationVariables(point, analysis)
                });
            });
        }
        
        return scenarios;
    }

    private buildDataCreationHelpers(analysis: ALCodeAnalysis): DataCreationHelper[] {
        const helpers: DataCreationHelper[] = [];
        
        // Add helper for creating test records
        if (analysis.objectType.toLowerCase() === 'tableextension') {
            const baseTableName = this.getBaseTableName(analysis);
            helpers.push({
                name: `Create${baseTableName}WithTestData`,
                parameters: `var ${baseTableName}: Record "${baseTableName}"`,
                returnType: undefined,
                implementation: this.generateTestRecordCreation(analysis)
            });
        }
        
        // Add helpers for setting up specific test scenarios
        analysis.procedures.forEach(proc => {
            if (proc.name.toLowerCase().includes('calculate')) {
                helpers.push({
                    name: `SetupCalculationTestData`,
                    parameters: '',
                    returnType: undefined,
                    implementation: this.generateCalculationTestSetup(proc, analysis)
                });
            }
        });
        
        return helpers;
    }

    // Helper methods for code generation
    private isCalculationProcedure(name: string): boolean {
        return name.toLowerCase().includes('calculate') || name.toLowerCase().includes('compute');
    }

    private isValidationProcedure(name: string): boolean {
        return name.toLowerCase().includes('validate') || name.toLowerCase().includes('check');
    }

    private isDataModificationProcedure(name: string): boolean {
        const lowerName = name.toLowerCase();
        return lowerName.includes('create') || lowerName.includes('update') || 
               lowerName.includes('modify') || lowerName.includes('delete') ||
               lowerName.includes('insert');
    }

    private toPascalCase(str: string): string {
        return str.replace(/\s+/g, '').replace(/^\w/, c => c.toUpperCase());
    }

    private formatParameters(parameters: any[]): string {
        return parameters.map(p => `${p.name}: ${p.type}`).join(', ');
    }

    private generateParameterValues(parameters: any[]): string {
        return parameters.map(p => this.generateValueForType(p.type)).join(', ');
    }

    private generateInvalidParameterValues(parameters: any[]): string {
        return parameters.map(p => this.generateInvalidValueForType(p.type)).join(', ');
    }

    private generateValueForType(type: string): string {
        const lowerType = type.toLowerCase();
        if (lowerType.includes('integer') || lowerType.includes('decimal')) {
            return 'LibraryRandom.RandInt(1000)';
        }
        if (lowerType.includes('text') || lowerType.includes('code')) {
            return `LibraryUtility.GenerateGUID()`;
        }
        if (lowerType.includes('boolean')) {
            return 'true';
        }
        if (lowerType.includes('date')) {
            return 'WorkDate()';
        }
        return '// TODO: Provide appropriate test value';
    }

    private generateInvalidValueForType(type: string): string {
        const lowerType = type.toLowerCase();
        if (lowerType.includes('integer') || lowerType.includes('decimal')) {
            return '-1';
        }
        if (lowerType.includes('text') || lowerType.includes('code')) {
            return `''`;
        }
        if (lowerType.includes('date')) {
            return '0D';
        }
        return '// TODO: Provide appropriate invalid value';
    }

    private generateLocalVariables(procedure: ALProcedure, analysis: ALCodeAnalysis): string {
        const variables: string[] = [];
        
        // Add object variable for the object being tested
        if (analysis.objectType.toLowerCase() === 'tableextension') {
            const baseTableName = this.getBaseTableName(analysis);
            variables.push(`${baseTableName}: Record "${baseTableName}";`);
        }
        
        // Add variables for procedure parameters
        procedure.parameters.forEach(param => {
            if (!param.isVar) {
                variables.push(`Test${param.name}: ${param.type};`);
            }
        });
        
        return variables.join('\n        ');
    }

    private getBaseTableName(analysis: ALCodeAnalysis): string {
        const match = analysis.objectName.match(/(\w+)\s+(Ext|Extension)/i);
        return match ? match[1] : 'TestRecord';
    }

    private generateRecordVariableName(baseTableName: string): string {
        return baseTableName.replace(/\s+/g, '');
    }

    private generateCreateRecordInstance(baseTableName: string, analysis: ALCodeAnalysis): string {
        const domain = analysis.businessContext?.domain;
        switch (domain) {
            case 'Sales':
                return `LibrarySales.Create${baseTableName}(${this.generateRecordVariableName(baseTableName)});`;
            case 'Purchase':
                return `LibraryPurchase.Create${baseTableName}(${this.generateRecordVariableName(baseTableName)});`;
            default:
                return `${this.generateRecordVariableName(baseTableName)}.Init();\n        ${this.generateRecordVariableName(baseTableName)}.Insert();`;
        }
    }

    private generateValidTestValues(field: ALField): any[] {
        const values: any[] = [];
        
        if (field.type.toLowerCase().includes('integer')) {
            values.push(0);
            if (field.maxValue) {
                values.push(field.maxValue);
                values.push(Math.floor(field.maxValue / 2));
            } else {
                values.push(100, 500);
            }
            if (field.minValue !== undefined) {
                values.push(field.minValue);
            }
        } else if (field.type.toLowerCase().includes('text')) {
            values.push(`'Test Value'`, `'A'`, `'Valid Text'`);
        }
        
        return values;
    }

    private generateConstraintViolations(field: ALField): ConstraintViolation[] {
        const violations: ConstraintViolation[] = [];
        
        if (field.minValue !== undefined) {
            violations.push({
                value: field.minValue - 1,
                expectedError: `must not be less than ${field.minValue}`
            });
        }
        
        if (field.maxValue !== undefined) {
            violations.push({
                value: field.maxValue + 1,
                expectedError: `must not be greater than ${field.maxValue}`
            });
        }
        
        return violations;
    }

    private generateSetupTestData(procedure: ALProcedure, analysis: ALCodeAnalysis): string {
        return `// Setup test data for ${procedure.name}\n        Initialize();`;
    }

    private generateBoundaryTestData(procedure: ALProcedure): string {
        return `// Setup boundary value test data\n        // TODO: Implement boundary test data setup`;
    }

    private generateInvalidTestData(procedure: ALProcedure): string {
        return `// Setup invalid test data\n        // TODO: Implement invalid test data setup`;
    }

    private generateBoundaryTestExecution(procedure: ALProcedure): string {
        return `// Execute boundary value tests\n        // TODO: Implement boundary value execution`;
    }

    private generateVerificationCode(procedure: ALProcedure, analysis: ALCodeAnalysis): string {
        return `// Verify expected behavior\n        // TODO: Implement verification logic`;
    }

    private generateExpectedErrorMessage(procedure: ALProcedure): string {
        return `Expected error for ${procedure.name}`;
    }

    private generateIntegrationSetup(point: string, analysis: ALCodeAnalysis): string {
        return `// Setup for ${point} integration\n        Initialize();`;
    }

    private generateIntegrationExecution(point: string, analysis: ALCodeAnalysis): string {
        return `// Execute ${point} integration\n        // TODO: Implement integration execution`;
    }

    private generateIntegrationVerification(point: string): string {
        return `// Verify ${point} integration results\n        // TODO: Implement integration verification`;
    }

    private generateIntegrationVariables(point: string, analysis: ALCodeAnalysis): string {
        return `// Variables for ${point} integration`;
    }

    private generateTestRecordCreation(analysis: ALCodeAnalysis): string {
        const baseTableName = this.getBaseTableName(analysis);
        return `// Create test ${baseTableName} with extended fields\n        Initialize();\n        // TODO: Implement test record creation`;
    }

    private generateCalculationTestSetup(procedure: ALProcedure, analysis: ALCodeAnalysis): string {
        return `// Setup test data for calculation procedure\n        // TODO: Implement calculation test setup`;
    }

    private generateInitializationCode(analysis: ALCodeAnalysis): string {
        const domain = analysis.businessContext?.domain;
        const initCode = ['// Initialize test environment'];
        
        switch (domain) {
            case 'Sales':
                initCode.push('LibrarySales.SetStockoutWarning(false);');
                break;
            case 'Purchase':
                initCode.push('LibraryPurchase.SetStockoutWarning(false);');
                break;
        }
        
        return initCode.join('\n        ');
    }

    private generateCleanupCode(analysis: ALCodeAnalysis): string {
        return `// Cleanup test data\n        Clear(LibraryAssert);`;
    }

    private getALTestTemplate(): string {
        // This would normally be loaded from a .hbs file
        // For now, return the basic template structure
        return `/// <summary>
/// Test Codeunit for: {{objectType}} {{objectId}} "{{objectName}}"
/// Generated by AL AI Test Generator
/// </summary>
codeunit {{testCodeunitId}} "{{testCodeunitName}}"
{
    Subtype = Test;
    TestIsolation = Codeunit;
    TestPermissions = Disabled;

    trigger OnRun()
    begin
        // [FEATURE] {{featureDescription}}
    end;

    var
        {{#each libraryVariables}}
        {{this}};
        {{/each}}
        IsInitialized: Boolean;

    {{#each procedures}}
    // ============================================================================
    // TESTS FOR PROCEDURE: {{name}}
    // ============================================================================
    
    [Test]
    procedure Test{{pascalCase}}_ValidInputs_ReturnsCorrectResult()
    var
        {{localVariables}}
    begin
        // [SCENARIO] Test {{name}} with valid inputs
        {{setupTestData}}

        // [WHEN] {{name}} is called
        // [THEN] Should execute successfully
        {{verificationCode}}
    end;
    {{/each}}

    {{#if fields}}
    // ============================================================================
    // FIELD VALIDATION TESTS
    // ============================================================================
    
    {{#each fields}}
    [Test]
    procedure TestField{{pascalCase}}_ValidValues_AcceptsCorrectly()
    var
        {{recordVariable}}: Record "{{baseTableName}}";
    begin
        // [SCENARIO] Test {{name}} field accepts valid values
        Initialize();

        // [GIVEN] A record instance
        {{createRecordInstance}}

        // [WHEN] Setting valid {{name}} values
        // [THEN] Values should be accepted
        {{#each validTestValues}}
        {{../recordVariable}}.{{../name}} := {{this}};
        {{../recordVariable}}.Modify();
        LibraryAssert.AreEqual({{this}}, {{../recordVariable}}.{{../name}}, 'Valid value {{this}} should be accepted');
        {{/each}}
    end;
    {{/each}}
    {{/if}}

    // ============================================================================
    // HELPER METHODS
    // ============================================================================

    local procedure Initialize()
    begin
        if IsInitialized then
            exit;

        {{initializationCode}}
        
        IsInitialized := true;
        Commit();
    end;

    {{#each dataCreationHelpers}}
    local procedure {{name}}({{parameters}}){{#if returnType}}: {{returnType}}{{/if}}
    begin
        {{implementation}}
    end;
    {{/each}}

    [TestSetup]
    procedure Setup()
    begin
        Initialize();
    end;

    [TestTeardown]
    procedure Teardown()
    begin
        {{cleanupCode}}
    end;
}`;
    }
}