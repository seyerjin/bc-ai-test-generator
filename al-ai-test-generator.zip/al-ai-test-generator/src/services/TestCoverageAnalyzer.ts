import * as vscode from 'vscode';
import * as path from 'path';
import { ALAnalyzer, ALCodeAnalysis } from './ALAnalyzer';

export interface CoverageReport {
    summary: CoverageSummary;
    objectCoverage: ObjectCoverage[];
    recommendations: CoverageRecommendation[];
    generatedAt: Date;
}

export interface CoverageSummary {
    totalObjects: number;
    testedObjects: number;
    coveragePercentage: number;
    totalProcedures: number;
    testedProcedures: number;
    procedureCoveragePercentage: number;
    totalFields: number;
    testedFields: number;
    fieldCoveragePercentage: number;
}

export interface ObjectCoverage {
    objectType: string;
    objectName: string;
    objectId: number;
    filePath: string;
    hasTests: boolean;
    testFilePath?: string;
    procedureCoverage: ProcedureCoverage[];
    fieldCoverage: FieldCoverage[];
    overallCoverage: number;
    complexity: 'Low' | 'Medium' | 'High';
    priority: 'Low' | 'Medium' | 'High';
}

export interface ProcedureCoverage {
    procedureName: string;
    isTested: boolean;
    testMethods: string[];
    coverageGaps: string[];
}

export interface FieldCoverage {
    fieldName: string;
    fieldType: string;
    isTested: boolean;
    hasValidationTests: boolean;
    hasBoundaryTests: boolean;
}

export interface CoverageRecommendation {
    type: 'Missing Tests' | 'Insufficient Coverage' | 'Test Quality' | 'Performance';
    priority: 'Low' | 'Medium' | 'High';
    objectName: string;
    description: string;
    suggestedAction: string;
}

export class TestCoverageAnalyzer {
    private alAnalyzer: ALAnalyzer;

    constructor() {
        this.alAnalyzer = new ALAnalyzer();
    }

    async analyzeCoverage(): Promise<CoverageReport> {
        try {
            // Find all AL files in workspace
            const alFiles = await vscode.workspace.findFiles('**/*.al', '**/test/**');
            const testFiles = await vscode.workspace.findFiles('**/test/**/*.al', null);

            // Analyze each AL object
            const objectCoverages: ObjectCoverage[] = [];
            
            for (const alFile of alFiles) {
                const coverage = await this.analyzeObjectCoverage(alFile, testFiles);
                if (coverage) {
                    objectCoverages.push(coverage);
                }
            }

            // Generate summary
            const summary = this.generateCoverageSummary(objectCoverages);
            
            // Generate recommendations
            const recommendations = this.generateRecommendations(objectCoverages);

            return {
                summary,
                objectCoverage: objectCoverages,
                recommendations,
                generatedAt: new Date()
            };

        } catch (error) {
            console.error('Coverage analysis error:', error);
            throw error;
        }
    }

    private async analyzeObjectCoverage(
        alFile: vscode.Uri, 
        testFiles: vscode.Uri[]
    ): Promise<ObjectCoverage | null> {
        try {
            const document = await vscode.workspace.openTextDocument(alFile);
            const alCode = document.getText();
            
            // Skip if this is already a test file
            if (this.isTestFile(alFile)) {
                return null;
            }

            const analysis = this.alAnalyzer.analyzeCode(alCode);
            
            // Find corresponding test files
            const testFile = this.findTestFile(alFile, testFiles);
            let testAnalysis: ALCodeAnalysis | null = null;
            
            if (testFile) {
                const testDocument = await vscode.workspace.openTextDocument(testFile);
                const testCode = testDocument.getText();
                testAnalysis = this.alAnalyzer.analyzeCode(testCode);
            }

            // Analyze procedure coverage
            const procedureCoverage = this.analyzeProcedureCoverage(analysis, testAnalysis);
            
            // Analyze field coverage
            const fieldCoverage = this.analyzeFieldCoverage(analysis, testAnalysis);
            
            // Calculate overall coverage
            const overallCoverage = this.calculateOverallCoverage(procedureCoverage, fieldCoverage);
            
            // Determine priority based on complexity and coverage
            const priority = this.determinePriority(analysis, overallCoverage);

            return {
                objectType: analysis.objectType,
                objectName: analysis.objectName,
                objectId: analysis.objectId,
                filePath: alFile.fsPath,
                hasTests: !!testFile,
                testFilePath: testFile?.fsPath,
                procedureCoverage,
                fieldCoverage,
                overallCoverage,
                complexity: analysis.complexity,
                priority
            };

        } catch (error) {
            console.error(`Error analyzing coverage for ${alFile.fsPath}:`, error);
            return null;
        }
    }

    private isTestFile(alFile: vscode.Uri): boolean {
        const fileName = path.basename(alFile.fsPath).toLowerCase();
        const filePath = alFile.fsPath.toLowerCase();
        
        return fileName.includes('test') || 
               filePath.includes('/test/') || 
               filePath.includes('\\test\\');
    }

    private findTestFile(alFile: vscode.Uri, testFiles: vscode.Uri[]): vscode.Uri | null {
        const baseName = path.basename(alFile.fsPath, '.al').toLowerCase();
        
        // Look for test files that reference this object
        for (const testFile of testFiles) {
            const testFileName = path.basename(testFile.fsPath, '.al').toLowerCase();
            
            // Check if test file name contains the object name
            if (testFileName.includes(baseName) || 
                testFileName.includes(baseName.replace(/\s+/g, '')) ||
                baseName.includes(testFileName.replace(/test/g, '').trim())) {
                return testFile;
            }
        }
        
        return null;
    }

    private analyzeProcedureCoverage(
        objectAnalysis: ALCodeAnalysis, 
        testAnalysis: ALCodeAnalysis | null
    ): ProcedureCoverage[] {
        const coverage: ProcedureCoverage[] = [];
        
        // Only analyze public procedures
        const publicProcedures = objectAnalysis.procedures.filter(p => !p.isLocal);
        
        for (const procedure of publicProcedures) {
            const testMethods = this.findTestMethodsForProcedure(procedure.name, testAnalysis);
            const coverageGaps = this.identifyProcedureCoverageGaps(procedure, testMethods);
            
            coverage.push({
                procedureName: procedure.name,
                isTested: testMethods.length > 0,
                testMethods,
                coverageGaps
            });
        }
        
        return coverage;
    }

    private analyzeFieldCoverage(
        objectAnalysis: ALCodeAnalysis, 
        testAnalysis: ALCodeAnalysis | null
    ): FieldCoverage[] {
        const coverage: FieldCoverage[] = [];
        
        if (!objectAnalysis.fields) {
            return coverage;
        }
        
        for (const field of objectAnalysis.fields) {
            const fieldTests = this.findTestMethodsForField(field.name, testAnalysis);
            const hasValidationTests = this.hasValidationTestsForField(field.name, testAnalysis);
            const hasBoundaryTests = this.hasBoundaryTestsForField(field.name, testAnalysis);
            
            coverage.push({
                fieldName: field.name,
                fieldType: field.type,
                isTested: fieldTests.length > 0,
                hasValidationTests,
                hasBoundaryTests
            });
        }
        
        return coverage;
    }

    private findTestMethodsForProcedure(procedureName: string, testAnalysis: ALCodeAnalysis | null): string[] {
        if (!testAnalysis) {
            return [];
        }
        
        const testMethods: string[] = [];
        const lowerProcedureName = procedureName.toLowerCase();
        
        for (const testProcedure of testAnalysis.procedures) {
            const testName = testProcedure.name.toLowerCase();
            if (testName.includes(lowerProcedureName) || testName.includes('test')) {
                testMethods.push(testProcedure.name);
            }
        }
        
        return testMethods;
    }

    private findTestMethodsForField(fieldName: string, testAnalysis: ALCodeAnalysis | null): string[] {
        if (!testAnalysis) {
            return [];
        }
        
        const testMethods: string[] = [];
        const lowerFieldName = fieldName.toLowerCase();
        
        for (const testProcedure of testAnalysis.procedures) {
            const testName = testProcedure.name.toLowerCase();
            if (testName.includes(lowerFieldName) && testName.includes('field')) {
                testMethods.push(testProcedure.name);
            }
        }
        
        return testMethods;
    }

    private hasValidationTestsForField(fieldName: string, testAnalysis: ALCodeAnalysis | null): boolean {
        if (!testAnalysis) {
            return false;
        }
        
        const lowerFieldName = fieldName.toLowerCase();
        
        return testAnalysis.procedures.some(proc => {
            const testName = proc.name.toLowerCase();
            return testName.includes(lowerFieldName) && 
                   (testName.includes('valid') || testName.includes('invalid'));
        });
    }

    private hasBoundaryTestsForField(fieldName: string, testAnalysis: ALCodeAnalysis | null): boolean {
        if (!testAnalysis) {
            return false;
        }
        
        const lowerFieldName = fieldName.toLowerCase();
        
        return testAnalysis.procedures.some(proc => {
            const testName = proc.name.toLowerCase();
            return testName.includes(lowerFieldName) && 
                   (testName.includes('boundary') || testName.includes('range') || 
                    testName.includes('min') || testName.includes('max'));
        });
    }

    private identifyProcedureCoverageGaps(procedure: any, testMethods: string[]): string[] {
        const gaps: string[] = [];
        
        if (testMethods.length === 0) {
            gaps.push('No tests found');
            return gaps;
        }
        
        // Check for specific test types based on procedure characteristics
        const testMethodsLower = testMethods.map(m => m.toLowerCase());
        
        if (procedure.name.toLowerCase().includes('calculate')) {
            if (!testMethodsLower.some(m => m.includes('boundary'))) {
                gaps.push('Missing boundary value tests');
            }
            if (!testMethodsLower.some(m => m.includes('invalid'))) {
                gaps.push('Missing invalid input tests');
            }
        }
        
        if (procedure.name.toLowerCase().includes('validate')) {
            if (!testMethodsLower.some(m => m.includes('error'))) {
                gaps.push('Missing error condition tests');
            }
        }
        
        if (procedure.returnType && procedure.returnType !== 'void') {
            if (!testMethodsLower.some(m => m.includes('return'))) {
                gaps.push('Missing return value tests');
            }
        }
        
        return gaps;
    }

    private calculateOverallCoverage(
        procedureCoverage: ProcedureCoverage[], 
        fieldCoverage: FieldCoverage[]
    ): number {
        const totalItems = procedureCoverage.length + fieldCoverage.length;
        if (totalItems === 0) {
            return 100; // No items to test
        }
        
        const testedProcedures = procedureCoverage.filter(p => p.isTested).length;
        const testedFields = fieldCoverage.filter(f => f.isTested).length;
        
        return Math.round((testedProcedures + testedFields) / totalItems * 100);
    }

    private determinePriority(analysis: ALCodeAnalysis, coverage: number): 'Low' | 'Medium' | 'High' {
        // High priority: High complexity objects with low coverage
        if (analysis.complexity === 'High' && coverage < 50) {
            return 'High';
        }
        
        // Medium priority: Medium complexity or medium coverage
        if (analysis.complexity === 'Medium' || (coverage >= 50 && coverage < 80)) {
            return 'Medium';
        }
        
        // Low priority: Low complexity or high coverage
        return 'Low';
    }

    private generateCoverageSummary(objectCoverages: ObjectCoverage[]): CoverageSummary {
        const totalObjects = objectCoverages.length;
        const testedObjects = objectCoverages.filter(o => o.hasTests).length;
        
        const totalProcedures = objectCoverages.reduce((sum, obj) => sum + obj.procedureCoverage.length, 0);
        const testedProcedures = objectCoverages.reduce((sum, obj) => 
            sum + obj.procedureCoverage.filter(p => p.isTested).length, 0);
        
        const totalFields = objectCoverages.reduce((sum, obj) => sum + obj.fieldCoverage.length, 0);
        const testedFields = objectCoverages.reduce((sum, obj) => 
            sum + obj.fieldCoverage.filter(f => f.isTested).length, 0);
        
        return {
            totalObjects,
            testedObjects,
            coveragePercentage: totalObjects > 0 ? Math.round(testedObjects / totalObjects * 100) : 0,
            totalProcedures,
            testedProcedures,
            procedureCoveragePercentage: totalProcedures > 0 ? Math.round(testedProcedures / totalProcedures * 100) : 0,
            totalFields,
            testedFields,
            fieldCoveragePercentage: totalFields > 0 ? Math.round(testedFields / totalFields * 100) : 0
        };
    }

    private generateRecommendations(objectCoverages: ObjectCoverage[]): CoverageRecommendation[] {
        const recommendations: CoverageRecommendation[] = [];
        
        // Find objects without tests
        const untestedObjects = objectCoverages.filter(o => !o.hasTests);
        for (const obj of untestedObjects) {
            recommendations.push({
                type: 'Missing Tests',
                priority: obj.priority,
                objectName: obj.objectName,
                description: `${obj.objectType} "${obj.objectName}" has no test coverage`,
                suggestedAction: `Create comprehensive test codeunit for ${obj.objectName}`
            });
        }
        
        // Find objects with low coverage
        const lowCoverageObjects = objectCoverages.filter(o => o.hasTests && o.overallCoverage < 70);
        for (const obj of lowCoverageObjects) {
            recommendations.push({
                type: 'Insufficient Coverage',
                priority: obj.priority,
                objectName: obj.objectName,
                description: `${obj.objectName} has only ${obj.overallCoverage}% test coverage`,
                suggestedAction: `Add tests for uncovered procedures and fields in ${obj.objectName}`
            });
        }
        
        // Find procedures with coverage gaps
        for (const obj of objectCoverages) {
            for (const proc of obj.procedureCoverage) {
                if (proc.isTested && proc.coverageGaps.length > 0) {
                    recommendations.push({
                        type: 'Test Quality',
                        priority: 'Medium',
                        objectName: obj.objectName,
                        description: `Procedure "${proc.procedureName}" has coverage gaps: ${proc.coverageGaps.join(', ')}`,
                        suggestedAction: `Improve test coverage for ${proc.procedureName} by adding missing test scenarios`
                    });
                }
            }
        }
        
        // Sort by priority
        return recommendations.sort((a, b) => {
            const priorityOrder = { 'High': 3, 'Medium': 2, 'Low': 1 };
            return priorityOrder[b.priority] - priorityOrder[a.priority];
        });
    }

    generateCoverageReport(coverage: CoverageReport): string {
        return `
<!DOCTYPE html>
<html>
<head>
    <title>AL Test Coverage Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; color: #333; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .summary-card { background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; border-left: 4px solid #007ACC; }
        .summary-card h3 { margin-top: 0; color: #007ACC; }
        .summary-card .percentage { font-size: 2em; font-weight: bold; color: #28a745; }
        .summary-card .details { color: #666; font-size: 0.9em; }
        .section { margin-bottom: 30px; }
        .section h2 { color: #333; border-bottom: 2px solid #007ACC; padding-bottom: 10px; }
        .object-list { display: grid; gap: 15px; }
        .object-card { background: #fff; border: 1px solid #ddd; border-radius: 6px; padding: 15px; }
        .object-header { display: flex; justify-content: between; align-items: center; margin-bottom: 10px; }
        .object-name { font-weight: bold; color: #333; }
        .coverage-bar { background: #e9ecef; height: 20px; border-radius: 10px; overflow: hidden; margin: 10px 0; }
        .coverage-fill { height: 100%; background: linear-gradient(90deg, #dc3545 0%, #ffc107 50%, #28a745 100%); transition: width 0.3s; }
        .recommendations { margin-top: 20px; }
        .recommendation { background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 4px; padding: 15px; margin-bottom: 10px; }
        .recommendation.high { border-left: 4px solid #dc3545; }
        .recommendation.medium { border-left: 4px solid #ffc107; }
        .recommendation.low { border-left: 4px solid #28a745; }
        .priority { font-weight: bold; text-transform: uppercase; font-size: 0.8em; }
        .high { color: #dc3545; }
        .medium { color: #ffc107; }
        .low { color: #28a745; }
        .no-tests { color: #dc3545; font-weight: bold; }
        .has-tests { color: #28a745; }
        .gaps { color: #666; font-size: 0.9em; margin-top: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>AL Test Coverage Report</h1>
            <p>Generated on ${coverage.generatedAt.toLocaleString()}</p>
        </div>

        <div class="summary">
            <div class="summary-card">
                <h3>Object Coverage</h3>
                <div class="percentage">${coverage.summary.coveragePercentage}%</div>
                <div class="details">${coverage.summary.testedObjects} of ${coverage.summary.totalObjects} objects have tests</div>
            </div>
            <div class="summary-card">
                <h3>Procedure Coverage</h3>
                <div class="percentage">${coverage.summary.procedureCoveragePercentage}%</div>
                <div class="details">${coverage.summary.testedProcedures} of ${coverage.summary.totalProcedures} procedures tested</div>
            </div>
            <div class="summary-card">
                <h3>Field Coverage</h3>
                <div class="percentage">${coverage.summary.fieldCoveragePercentage}%</div>
                <div class="details">${coverage.summary.testedFields} of ${coverage.summary.totalFields} fields tested</div>
            </div>
        </div>

        <div class="section">
            <h2>Object Coverage Details</h2>
            <div class="object-list">
                ${coverage.objectCoverage.map(obj => `
                    <div class="object-card">
                        <div class="object-header">
                            <span class="object-name">${obj.objectType} "${obj.objectName}"</span>
                            <span class="${obj.hasTests ? 'has-tests' : 'no-tests'}">
                                ${obj.hasTests ? '✓ Has Tests' : '✗ No Tests'}
                            </span>
                            <span class="priority ${obj.priority.toLowerCase()}">
                                ${obj.priority} Priority
                            </span>
                        </div>
                        <div class="coverage-bar">
                            <div class="coverage-fill" style="width: ${obj.overallCoverage}%"></div>
                        </div>
                        <div>Coverage: ${obj.overallCoverage}% | Complexity: ${obj.complexity}</div>
                        ${obj.procedureCoverage.some(p => p.coverageGaps.length > 0) ? `
                            <div class="gaps">
                                Coverage gaps: ${obj.procedureCoverage
                                    .filter(p => p.coverageGaps.length > 0)
                                    .map(p => `${p.procedureName} (${p.coverageGaps.join(', ')})`)
                                    .join('; ')
                                }
                            </div>
                        ` : ''}
                    </div>
                `).join('')}
            </div>
        </div>

        <div class="section">
            <h2>Recommendations</h2>
            <div class="recommendations">
                ${coverage.recommendations.map(rec => `
                    <div class="recommendation ${rec.priority.toLowerCase()}">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <strong>${rec.type}</strong>
                            <span class="priority ${rec.priority.toLowerCase()}">${rec.priority}</span>
                        </div>
                        <div style="margin: 10px 0;">
                            <strong>${rec.objectName}:</strong> ${rec.description}
                        </div>
                        <div style="color: #666;">
                            <em>Suggested Action:</em> ${rec.suggestedAction}
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    </div>
</body>
</html>`;
    }
}