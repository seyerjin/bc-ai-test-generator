// src/services/TestGenerator.ts - Microsoft-konforme Implementierung
import * as vscode from 'vscode';
import { ClaudeService, TestGenerationOptions } from './ClaudeService';
import { ALAnalyzer, ALCodeAnalysis } from './ALAnalyzer';

export class TestGenerator {
    private nextTestId = 59000; // Starting ID for test codeunits
    
    constructor(
        private claudeService: ClaudeService,
        private alAnalyzer: ALAnalyzer
    ) {}

    async analyzeCode(alCode: string): Promise<ALCodeAnalysis> {
        return this.alAnalyzer.analyzeCode(alCode);
    }

    async generateCombinedTests(
        analyses: ALCodeAnalysis[],
        testCodeunitName: string,
        options: TestGenerationOptions,
        cancellationToken?: vscode.CancellationToken
    ): Promise<string> {
        try {
            // Generate Microsoft-compliant test codeunit structure
            const codeunitId = this.getNextTestId();
            
            // Get AI-generated test content
            let testContent = await this.claudeService.generateTests(
                { 
                    objectType: 'Combined',
                    objectName: testCodeunitName,
                    objectId: codeunitId,
                    procedures: analyses.flatMap(a => a.procedures),
                    fields: analyses.flatMap(a => a.fields),
                    complexity: this.getCombinedComplexity(analyses),
                    dependencies: [...new Set(analyses.flatMap(a => a.dependencies))]
                },
                options,
                cancellationToken
            );
            
            // Clean up the generated content (remove code block markers)
            testContent = this.cleanGeneratedCode(testContent);
            
            // Build final test codeunit following Microsoft standards
            return this.buildMicrosoftCompliantTestCodeunit(
                codeunitId,
                testCodeunitName,
                analyses,
                testContent,
                options
            );
        } catch (error: any) {
            console.error('Combined test generation error:', error);
            throw error;
        }
    }

    private buildMicrosoftCompliantTestCodeunit(
        codeunitId: number,
        testCodeunitName: string,
        analyses: ALCodeAnalysis[],
        aiGeneratedContent: string,
        options: TestGenerationOptions
    ): string {
        const sanitizedName = testCodeunitName.replace(/[^a-zA-Z0-9_]/g, '_');
        const sourceObjects = analyses.map(a => `${a.objectType} ${a.objectId} "${a.objectName}"`).join(', ');
        
        // Microsoft-konformer Header
        const header = `/// <summary>
/// AI-generated test codeunit for ${sourceObjects}
/// Generated following Microsoft Dynamics 365 Business Central test standards
/// Framework: AL Test Framework
/// </summary>
codeunit ${codeunitId} "${sanitizedName}"
{
    Subtype = Test;
    TestPermissions = Disabled;
    TestIsolation = Codeunit;
    
    var
        LibraryAssert: Codeunit "Library Assert";
        LibraryTestInitialize: Codeunit "Library - Test Initialize";
        IsInitialized: Boolean;
`;

        // Setup/Teardown-Methoden gemäß Microsoft-Standards
        const setupTeardown = `
    [TestSetup]
    procedure TestSetup()
    begin
        LibraryTestInitialize.OnTestInitialize(CODEUNIT::"${sanitizedName}");
        if IsInitialized then
            exit;
        
        // Global setup for all tests
        IsInitialized := true;
        Commit();
    end;

    [TestTeardown]
    procedure TestTeardown()
    begin
        // Cleanup after each test
        Clear(IsInitialized);
    end;
`;

        // AI-generierte Test-Methoden mit Microsoft-Standards verarbeiten
        const processedTestMethods = this.processAIGeneratedMethods(aiGeneratedContent, analyses, options);

        // Helper-Methoden für Test-Unterstützung
        const helperMethods = this.generateHelperMethods(analyses);

        const footer = `}`;

        return `${header}${setupTeardown}${processedTestMethods}${helperMethods}${footer}`;
    }

    private processAIGeneratedMethods(
        aiContent: string,
        analyses: ALCodeAnalysis[],
        options: TestGenerationOptions
    ): string {
        let processedContent = aiContent;

        // Entferne Code-Block-Marker
        processedContent = this.cleanGeneratedCode(processedContent);

        // Stelle sicher, dass alle Test-Methoden das [Test]-Attribut haben
        processedContent = processedContent.replace(
            /(?:^|\n)(\s*)(procedure\s+Test\w+)/gmi,
            '\n$1[Test]\n$1$2'
        );

        // Füge TransactionModel-Attribute hinzu wo angebracht
        if (options.includeIntegrationTests) {
            processedContent = processedContent.replace(
                /(\[Test\][\s\n]*)(procedure\s+Test\w*Integration\w*)/gmi,
                '$1[TransactionModel(TransactionModel::AutoRollback)]\n    $2'
            );
        }

        // Stelle sicher, dass Assert-Statements Library Assert verwenden
        processedContent = processedContent.replace(
            /\bAssert\./gmi,
            'LibraryAssert.'
        );

        // Füge Given-When-Then-Kommentare hinzu
        processedContent = this.addGivenWhenThenStructure(processedContent);

        return processedContent;
    }

    private addGivenWhenThenStructure(content: string): string {
        return content.replace(
            /(procedure\s+Test\w+.*?\n[\s\S]*?begin)/gmi,
            (match) => {
                if (!match.includes('// Given') && !match.includes('// When') && !match.includes('// Then')) {
                    const lines = match.split('\n');
                    const beginIndex = lines.findIndex(line => line.trim().toLowerCase() === 'begin');
                    if (beginIndex > -1) {
                        lines.splice(beginIndex + 1, 0, 
                            '        // Given',
                            '',
                            '        // When', 
                            '',
                            '        // Then'
                        );
                    }
                    return lines.join('\n');
                }
                return match;
            }
        );
    }

    private generateHelperMethods(analyses: ALCodeAnalysis[]): string {
        let helpers = '\n    // Helper Methods\n';

        // Generiere Mock-Setup-Methoden für gefundene Records
        const recordTypes = new Set<string>();
        analyses.forEach(analysis => {
            analysis.dependencies.forEach(dep => {
                if (dep.startsWith('Record:')) {
                    recordTypes.add(dep.replace('Record: ', ''));
                }
            });
        });

        recordTypes.forEach(recordType => {
            const sanitizedType = recordType.replace(/[^a-zA-Z0-9_]/g, '_');
            helpers += `
    local procedure Setup${sanitizedType}TestData(): Record "${recordType}"
    var
        ${sanitizedType}Rec: Record "${recordType}";
    begin
        ${sanitizedType}Rec.Init();
        // Setup test data for ${recordType}
        ${sanitizedType}Rec.Insert(true);
        exit(${sanitizedType}Rec);
    end;
`;
        });

        return helpers;
    }

    private cleanGeneratedCode(content: string): string {
        // Entferne Markdown Code-Block-Marker
        content = content.replace(/```\w*\n?/g, '');
        content = content.replace(/```\n?/g, '');
        
        // Entferne führende/nachgestellte Leerzeichen
        content = content.trim();
        
        // Entferne doppelte Leerzeilen
        content = content.replace(/\n\s*\n\s*\n/g, '\n\n');
        
        return content;
    }

    private getNextTestId(): number {
        return this.nextTestId++;
    }

    private getCombinedComplexity(analyses: ALCodeAnalysis[]): 'Low' | 'Medium' | 'High' {
        const complexities = analyses.map(a => a.complexity);
        
        if (complexities.every(c => c === 'Low')) return 'Low';
        if (complexities.some(c => c === 'High')) return 'High';
        return 'Medium';
    }
}