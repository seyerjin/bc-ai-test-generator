import * as assert from 'assert';
import * as vscode from 'vscode';

suite('Extension Test Suite', () => {
    vscode.window.showInformationMessage('Start all tests.');

    test('Sample test', () => {
        assert.strictEqual(-1, [1, 2, 3].indexOf(5));
        assert.strictEqual(-1, [1, 2, 3].indexOf(0));
    });

    test('VS Code API availability', () => {
        assert.ok(vscode.window);
        assert.ok(vscode.workspace);
        assert.ok(vscode.commands);
    });

    test('Extension command registration', async () => {
        // Test that our commands are available
        const commands = await vscode.commands.getCommands();
        
        // Check for some basic VS Code commands
        assert.ok(commands.length > 0);
        assert.ok(commands.includes('workbench.action.openSettings'));
    });

    test('Configuration access', () => {
        // Test VS Code configuration access
        const config = vscode.workspace.getConfiguration('alAiTestGen');
        assert.ok(config !== undefined);
        
        // Test getting a configuration value with default
        const testComplexity = config.get('testComplexity', 'comprehensive');
        assert.ok(typeof testComplexity === 'string');
    });

    test('File system operations', async () => {
        // Test basic file system operations
        const workspaceFolders = vscode.workspace.workspaceFolders;
        
        // This might be undefined in test environment, which is fine
        if (workspaceFolders) {
            assert.ok(Array.isArray(workspaceFolders));
        }
        
        // Test URI creation
        const testUri = vscode.Uri.file('/test/path');
        assert.ok(testUri);
        assert.strictEqual(testUri.scheme, 'file');
    });
});