// Type definitions for AL AI Test Generator

export interface BusinessContext {
    domain: string;
    dataFlow: string[];
    businessRules: string[];
    integrationPoints: string[];
}

export interface TestScenario {
    type: string;
    description: string;
    priority: 'Low' | 'Medium' | 'High';
    estimatedComplexity?: number;
    requiredSetup?: string[];
    expectedOutcome?: string;
}

export interface TestStrategy {
    objectName: string;
    approach: string;
    testTypes: string[];
    setupRequirements: string[];
    estimatedDuration?: number;
    riskLevel?: 'Low' | 'Medium' | 'High';
    dependencies?: string[];
}

export interface EnhancedAnalysis {
    objectType: string;
    objectName: string;
    objectId: number;
    procedures: any[];
    fields: any[];
    complexity: 'Low' | 'Medium' | 'High';
    dependencies: string[];
    testStrategies: TestStrategy[];
    mockingRequirements: string[];
    dataSetupStrategies: string[];
    businessContext?: BusinessContext;
    testableScenarios?: TestScenario[];
}

export interface TestGenerationMetrics {
    startTime: Date;
    endTime?: Date;
    duration?: number;
    linesOfCode: number;
    testMethodsGenerated: number;
    complexityScore: number;
    coverageEstimate: number;
    aiTokensUsed?: number;
    successRate: number;
}

export interface TestQualityMetrics {
    codeQuality: number; // 0-100
    testCoverage: number; // 0-100
    maintainability: number; // 0-100
    readability: number; // 0-100
    performance: number; // 0-100
    businessLogicCoverage: number; // 0-100
}

export interface CodeAnalysisResult {
    objectType: string;
    objectName: string;
    objectId: number;
    procedures: ProcedureInfo[];
    fields: FieldInfo[];
    triggers: TriggerInfo[];
    events: EventInfo[];
    complexity: ComplexityMetrics;
    dependencies: DependencyInfo[];
    businessContext: BusinessContext;
    testableScenarios: TestScenario[];
    qualityIndicators: QualityIndicator[];
}

export interface ProcedureInfo {
    name: string;
    visibility: 'Public' | 'Local' | 'Internal';
    parameters: ParameterInfo[];
    returnType?: string;
    complexity: number;
    linesOfCode: number;
    cyclomaticComplexity: number;
    isTestable: boolean;
    testPriority: 'Low' | 'Medium' | 'High';
    estimatedTestCases: number;
    businessLogic: BusinessLogicInfo[];
}

export interface ParameterInfo {
    name: string;
    type: string;
    isVar: boolean;
    isOptional: boolean;
    description?: string;
    constraints?: ParameterConstraint[];
}

export interface ParameterConstraint {
    type: 'Range' | 'Length' | 'Format' | 'Required' | 'Enum';
    value: any;
    errorMessage?: string;
}

export interface FieldInfo {
    id: number;
    name: string;
    type: string;
    length?: number;
    required: boolean;
    editable: boolean;
    constraints: FieldConstraint[];
    businessRules: BusinessRule[];
    testPriority: 'Low' | 'Medium' | 'High';
    validationTests: ValidationTestInfo[];
}

export interface FieldConstraint {
    type: 'MinValue' | 'MaxValue' | 'Length' | 'Format' | 'TableRelation' | 'OptionString';
    value: any;
    errorMessage?: string;
}

export interface BusinessRule {
    description: string;
    condition: string;
    action: string;
    priority: 'Low' | 'Medium' | 'High';
    testable: boolean;
}

export interface ValidationTestInfo {
    testType: 'Positive' | 'Negative' | 'Boundary' | 'Edge';
    testValue: any;
    expectedResult: 'Pass' | 'Fail' | 'Error';
    description: string;
}

export interface TriggerInfo {
    name: string;
    type: 'OnValidate' | 'OnLookup' | 'OnDrillDown' | 'OnInsert' | 'OnModify' | 'OnDelete' | 'OnRename';
    complexity: number;
    hasBusinessLogic: boolean;
    testable: boolean;
}

export interface EventInfo {
    name: string;
    type: 'Publisher' | 'Subscriber';
    eventType: string;
    parameters: ParameterInfo[];
    testable: boolean;
    integrationTestRequired: boolean;
}

export interface ComplexityMetrics {
    overall: 'Low' | 'Medium' | 'High';
    cyclomaticComplexity: number;
    cognitiveComplexity: number;
    linesOfCode: number;
    numberOfProcedures: number;
    numberOfFields: number;
    dependencyCount: number;
    estimatedTestingEffort: number; // in hours
}

export interface DependencyInfo {
    name: string;
    type: 'Record' | 'Codeunit' | 'Page' | 'Report' | 'XmlPort' | 'Query';
    usage: 'Read' | 'Write' | 'Execute' | 'Reference';
    mockable: boolean;
    testImpact: 'Low' | 'Medium' | 'High';
}

export interface QualityIndicator {
    category: 'Code Quality' | 'Maintainability' | 'Performance' | 'Security' | 'Best Practice';
    severity: 'Info' | 'Warning' | 'Error';
    description: string;
    recommendation: string;
    impact: 'Low' | 'Medium' | 'High';
}

export interface BusinessLogicInfo {
    description: string;
    type: 'Calculation' | 'Validation' | 'Transformation' | 'Integration' | 'Workflow';
    complexity: number;
    testScenarios: string[];
    riskLevel: 'Low' | 'Medium' | 'High';
}

export interface TestGenerationOptions {
    testComplexity: 'basic' | 'comprehensive' | 'advanced';
    includeIntegrationTests: boolean;
    includeMocks: boolean;
    includePerformanceTests: boolean;
    maxTestsPerProcedure: number;
    testDataStrategy?: 'minimal' | 'realistic' | 'comprehensive';
    enableAutomaticMocking?: boolean;
    generateDocumentation?: boolean;
    includeCodeCoverage?: boolean;
    followNamingConventions?: boolean;
    useGivenWhenThen?: boolean;
    includeSetupTeardown?: boolean;
    generateNegativeTests?: boolean;
    includeBoundaryTests?: boolean;
    generatePerformanceTests?: boolean;
    customTemplates?: string[];
    aiProvider?: 'claude' | 'openai' | 'azure';
    maxTokensPerRequest?: number;
    temperature?: number;
}

export interface TestGenerationResult {
    success: boolean;
    testCode: string;
    metrics: TestGenerationMetrics;
    qualityScore: TestQualityMetrics;
    warnings: string[];
    errors: string[];
    suggestions: string[];
    metadata: TestFileMetadata;
}

export interface TestFileMetadata {
    originalFile: string;
    testFile: string;
    objectType: string;
    objectName: string;
    generatedAt: Date;
    generatorVersion: string;
    testFramework: string;
    complexity: string;
    totalTestMethods: number;
    estimatedCoverage: number;
    sourceFileHash: string;
    dependencies: string[];
    customizations: string[];
}

export interface TestExecutionResult {
    testFile: string;
    testMethod: string;
    status: 'Passed' | 'Failed' | 'Error' | 'Skipped';
    duration: number;
    message?: string;
    stackTrace?: string;
    coverage?: CoverageInfo;
    performance?: PerformanceInfo;
}

export interface CoverageInfo {
    procedureName: string;
    linesCovered: number;
    totalLines: number;
    coveragePercentage: number;
    uncoveredLines: number[];
    branchCoverage: number;
}

export interface PerformanceInfo {
    executionTime: number;
    memoryUsage: number;
    databaseCalls: number;
    performanceIssues: PerformanceIssue[];
}

export interface PerformanceIssue {
    type: 'Slow Query' | 'Memory Leak' | 'Infinite Loop' | 'Resource Contention';
    severity: 'Low' | 'Medium' | 'High' | 'Critical';
    description: string;
    recommendation: string;
    location: string;
}

export interface TestSuite {
    name: string;
    description: string;
    testFiles: TestFileInfo[];
    totalTests: number;
    passedTests: number;
    failedTests: number;
    skippedTests: number;
    executionTime: number;
    coverage: SuiteCoverageInfo;
    generatedAt: Date;
    lastExecuted?: Date;
}

export interface TestFileInfo {
    fileName: string;
    filePath: string;
    objectName: string;
    objectType: string;
    testMethods: TestMethodInfo[];
    dependencies: string[];
    setup: string[];
    teardown: string[];
}

export interface TestMethodInfo {
    name: string;
    description: string;
    category: string;
    priority: 'Low' | 'Medium' | 'High';
    estimatedDuration: number;
    requiredSetup: string[];
    expectedOutcome: string;
    tags: string[];
}

export interface SuiteCoverageInfo {
    overallCoverage: number;
    procedureCoverage: number;
    fieldCoverage: number;
    branchCoverage: number;
    objectCoverage: ObjectCoverageInfo[];
}

export interface ObjectCoverageInfo {
    objectName: string;
    objectType: string;
    coverage: number;
    proceduresCovered: number;
    totalProcedures: number;
    fieldsCovered: number;
    totalFields: number;
}

export interface MockConfiguration {
    objectName: string;
    objectType: string;
    mockType: 'Simple' | 'Behavior' | 'State' | 'Interaction';
    setup: MockSetup[];
    behaviors: MockBehavior[];
    verifications: MockVerification[];
}

export interface MockSetup {
    procedureName: string;
    parameters: any[];
    returnValue?: any;
    throwError?: string;
    callCount?: number;
}

export interface MockBehavior {
    condition: string;
    action: string;
    priority: number;
}

export interface MockVerification {
    type: 'CallCount' | 'Parameters' | 'Order' | 'State';
    expected: any;
    description: string;
}

export interface TestDataGenerator {
    objectType: string;
    generatorType: 'Random' | 'Sequential' | 'Realistic' | 'Custom';
    fields: TestDataFieldConfig[];
    constraints: TestDataConstraint[];
    relationships: TestDataRelationship[];
}

export interface TestDataFieldConfig {
    fieldName: string;
    dataType: string;
    generationType: 'Random' | 'Sequential' | 'FixedValue' | 'Formula' | 'Lookup';
    configuration: any;
}

export interface TestDataConstraint {
    fieldName: string;
    constraintType: 'Unique' | 'Required' | 'Range' | 'Format' | 'Custom';
    value: any;
}

export interface TestDataRelationship {
    relatedObject: string;
    relationshipType: 'OneToOne' | 'OneToMany' | 'ManyToOne' | 'ManyToMany';
    keyFields: string[];
}

export interface ContinuousIntegrationConfig {
    enabled: boolean;
    triggerEvents: ('Push' | 'PullRequest' | 'Schedule')[];
    testSuites: string[];
    coverageThreshold: number;
    performanceThreshold: number;
    notifications: NotificationConfig[];
    reportFormat: 'HTML' | 'XML' | 'JSON' | 'Text';
}

export interface NotificationConfig {
    type: 'Email' | 'Slack' | 'Teams' | 'Webhook';
    configuration: any;
    conditions: NotificationCondition[];
}

export interface NotificationCondition {
    event: 'TestFailed' | 'CoverageDropped' | 'PerformanceRegression' | 'AllTestsPassed';
    threshold?: number;
}

export interface AIProviderConfig {
    provider: 'claude' | 'openai' | 'azure' | 'custom';
    apiKey: string;
    baseUrl?: string;
    model: string;
    maxTokens: number;
    temperature: number;
    topP?: number;
    frequencyPenalty?: number;
    presencePenalty?: number;
    customHeaders?: { [key: string]: string };
    retryConfig?: {
        maxRetries: number;
        backoffMs: number;
        exponentialBackoff: boolean;
    };
}

// Error types
export class TestGenerationError extends Error {
    constructor(
        message: string,
        public code: string,
        public details?: any
    ) {
        super(message);
        this.name = 'TestGenerationError';
    }
}

export class CodeAnalysisError extends Error {
    constructor(
        message: string,
        public file: string,
        public line?: number,
        public column?: number
    ) {
        super(message);
        this.name = 'CodeAnalysisError';
    }
}

export class AIProviderError extends Error {
    constructor(
        message: string,
        public provider: string,
        public statusCode?: number,
        public response?: any
    ) {
        super(message);
        this.name = 'AIProviderError';
    }
}

// Utility types
export type TestComplexity = 'basic' | 'comprehensive' | 'advanced';
export type ObjectType = 'table' | 'tableextension' | 'page' | 'pageextension' | 'codeunit' | 'report' | 'xmlport' | 'query' | 'enum' | 'enumextension';
export type TestPriority = 'Low' | 'Medium' | 'High';
export type TestStatus = 'Passed' | 'Failed' | 'Error' | 'Skipped' | 'NotRun';
export type MockType = 'Simple' | 'Behavior' | 'State' | 'Interaction';
export type DataGenerationType = 'Random' | 'Sequential' | 'Realistic' | 'Custom';
export type BusinessDomain = 'Sales' | 'Purchase' | 'Finance' | 'Inventory' | 'Manufacturing' | 'HumanResources' | 'General';

// Constants
export const TEST_FRAMEWORK_VERSION = '1.0.0';
export const SUPPORTED_AL_VERSIONS = ['6.0', '7.0', '8.0', '9.0', '10.0'];
export const DEFAULT_TEST_CODEUNIT_ID_RANGE = { start: 59000, end: 59999 };
export const MAX_TESTS_PER_PROCEDURE = 20;
export const DEFAULT_COVERAGE_THRESHOLD = 80;
export const DEFAULT_PERFORMANCE_THRESHOLD = 1000; // ms

// Enums
export enum TestMethodType {
    UnitTest = 'UnitTest',
    IntegrationTest = 'IntegrationTest',
    PerformanceTest = 'PerformanceTest',
    ValidationTest = 'ValidationTest',
    BoundaryTest = 'BoundaryTest',
    ErrorHandlingTest = 'ErrorHandlingTest',
    MockTest = 'MockTest'
}

export enum CodeQualityLevel {
    Excellent = 90,
    Good = 75,
    Average = 60,
    Poor = 40,
    VeryPoor = 0
}

export enum ComplexityLevel {
    Low = 1,
    Medium = 2,
    High = 3,
    VeryHigh = 4,
    Extreme = 5
}