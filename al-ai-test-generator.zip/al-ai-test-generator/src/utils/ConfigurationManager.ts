import * as vscode from 'vscode';

export class ConfigurationManager {
    private static readonly API_KEY_SECRET = 'alAiTestGen.claudeApiKey';
    private static readonly FIRST_ACTIVATION_KEY = 'hasActivated';
    
    constructor(private context: vscode.ExtensionContext) {}

    /**
     * Get the stored API key from secure storage or settings
     * @returns Promise<string | undefined> - The API key if found
     */
    async getApiKey(): Promise<string | undefined> {
        // First check secret storage (secure)
        let apiKey = await this.context.secrets.get(ConfigurationManager.API_KEY_SECRET);
        
        // Fallback to settings (less secure, for backwards compatibility)
        if (!apiKey) {
            const config = vscode.workspace.getConfiguration('alAiTestGen');
            apiKey = config.get<string>('claudeApiKey');
        }
        
        return apiKey;
    }

    /**
     * Configure the Claude API key through user input
     * @returns Promise<boolean> - true if configuration was successful
     */
    async configure(): Promise<boolean> {
        try {
            const apiKey = await vscode.window.showInputBox({
                prompt: 'Please configure your API key',
                placeHolder: 'Enter your Claude API key (sk-ant-api...)',
                password: true,
                ignoreFocusOut: true,
                validateInput: (value) => {
                    if (!value || value.trim().length === 0) {
                        return 'API key is required';
                    }
                    if (!value.startsWith('sk-ant-')) {
                        return 'Invalid API key format. Claude API keys start with "sk-ant-"';
                    }
                    if (value.length < 20) {
                        return 'API key appears to be too short';
                    }
                    return null;
                }
            });

            if (apiKey && apiKey.trim().length > 0) {
                // Store in secure secret storage
                await this.context.secrets.store(ConfigurationManager.API_KEY_SECRET, apiKey.trim());
                
                // Remove from settings if it exists there (migration to secure storage)
                const config = vscode.workspace.getConfiguration('alAiTestGen');
                if (config.get<string>('claudeApiKey')) {
                    await config.update('claudeApiKey', undefined, vscode.ConfigurationTarget.Global);
                }
                
                vscode.window.showInformationMessage('API key saved securely');
                return true;
            }
            
            return false;
        } catch (error: any) {
            console.error('Configuration error:', error);
            vscode.window.showErrorMessage(`Configuration failed: ${error.message}`);
            return false;
        }
    }

    /**
     * Check if this is the first activation of the extension
     * @returns boolean - true if this is the first activation
     */
    isFirstActivation(): boolean {
        const globalState = this.context.globalState;
        const hasActivated = globalState.get<boolean>(ConfigurationManager.FIRST_ACTIVATION_KEY, false);
        
        if (!hasActivated) {
            globalState.update(ConfigurationManager.FIRST_ACTIVATION_KEY, true);
            return true;
        }
        
        return false;
    }

    /**
     * Check if API key is configured
     * @returns Promise<boolean> - true if API key exists
     */
    async isConfigured(): Promise<boolean> {
        const apiKey = await this.getApiKey();
        return !!apiKey && apiKey.trim().length > 0;
    }

    /**
     * Clear the stored API key (for testing or troubleshooting)
     * @returns Promise<void>
     */
    async clearApiKey(): Promise<void> {
        await this.context.secrets.delete(ConfigurationManager.API_KEY_SECRET);
        const config = vscode.workspace.getConfiguration('alAiTestGen');
        await config.update('claudeApiKey', undefined, vscode.ConfigurationTarget.Global);
        vscode.window.showInformationMessage('API key cleared');
    }

    /**
     * Get extension configuration settings
     * @returns Configuration object with current settings
     */
    getConfiguration() {
        const config = vscode.workspace.getConfiguration('alAiTestGen');
        return {
            testFramework: config.get<string>('testFramework', 'AL Test Framework'),
            testComplexity: config.get<string>('testComplexity', 'comprehensive') as 'basic' | 'comprehensive' | 'exhaustive',
            generateMocks: config.get<boolean>('generateMocks', true),
            maxTestsPerFile: config.get<number>('maxTestsPerFile', 20),
            includeIntegrationTests: config.get<boolean>('includeIntegrationTests', true),
            includePerformanceTests: config.get<boolean>('includePerformanceTests', false)
        };
    }

    /**
     * Update extension configuration
     * @param key - Configuration key to update
     * @param value - New value for the configuration
     * @returns Promise<void>
     */
    async updateConfiguration(key: string, value: any): Promise<void> {
        const config = vscode.workspace.getConfiguration('alAiTestGen');
        await config.update(key, value, vscode.ConfigurationTarget.Global);
    }

    /**
     * Reset first activation flag (for testing)
     * @returns Promise<void>
     */
    async resetFirstActivation(): Promise<void> {
        await this.context.globalState.update(ConfigurationManager.FIRST_ACTIVATION_KEY, false);
    }

    /**
     * Show configuration help/instructions
     */
    showConfigurationHelp(): void {
        const helpMessage = `
To configure the AL AI Test Generator:

1. Get your Claude API key from https://console.anthropic.com/
2. Use Ctrl+Shift+P and search for "AL: Configure AI Test Generator"
3. Enter your API key (starts with sk-ant-)
4. The connection will be tested automatically

Your API key is stored securely using VS Code's secret storage.
        `.trim();

        vscode.window.showInformationMessage(
            'Configuration Help',
            { modal: true, detail: helpMessage },
            'Get API Key',
            'Configure Now'
        ).then(selection => {
            if (selection === 'Get API Key') {
                vscode.env.openExternal(vscode.Uri.parse('https://console.anthropic.com/'));
            } else if (selection === 'Configure Now') {
                this.configure();
            }
        });
    }
}