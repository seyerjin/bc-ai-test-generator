// src/utils/FileManager.ts - Vollständige Implementierung
import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs/promises';

export interface ALFile {
    name: string;
    uri: vscode.Uri;
}

export class FileManager {
    async createCombinedTestFile(
        sourceUri: vscode.Uri, 
        testCode: string,
        testCodeunitName: string
    ): Promise<vscode.Uri> {
        const sourcePath = sourceUri.fsPath;
        const sourceDir = path.dirname(sourcePath);
        
        // Create test directory if it doesn't exist
        const testDir = path.join(sourceDir, '..', 'test');
        await this.ensureDirectoryExists(testDir);
        
        // Generate test file name based on codeunit name
        const safeFileName = testCodeunitName
            .replace(/[^a-zA-Z0-9]/g, '_')
            .replace(/_+/g, '_');
        const codeunitId = this.extractCodeunitId(testCode);
        const testFileName = `Cod${codeunitId}.${safeFileName}.al`;
        const testFilePath = path.join(testDir, testFileName);
        
        // Check if file already exists
        const fileExists = await this.fileExists(testFilePath);
        if (fileExists) {
            const overwrite = await vscode.window.showQuickPick(
                ['Overwrite', 'Create New Version', 'Cancel'],
                { 
                    placeHolder: `Test file ${testFileName} already exists. What would you like to do?`,
                    canPickMany: false
                }
            );
            
            if (overwrite === 'Cancel') {
                throw new Error('Test file creation cancelled');
            } else if (overwrite === 'Create New Version') {
                const timestamp = new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-');
                const versionedFileName = `Cod${codeunitId}.${safeFileName}.${timestamp}.al`;
                const versionedFilePath = path.join(testDir, versionedFileName);
                await fs.writeFile(versionedFilePath, testCode, 'utf8');
                return vscode.Uri.file(versionedFilePath);
            }
        }
        
        // Write test file
        await fs.writeFile(testFilePath, testCode, 'utf8');
        
        return vscode.Uri.file(testFilePath);
    }

    async createSingleTestFile(
        sourceUri: vscode.Uri,
        testCode: string
    ): Promise<vscode.Uri> {
        const sourcePath = sourceUri.fsPath;
        const sourceFileName = path.basename(sourcePath, '.al');
        const sourceDir = path.dirname(sourcePath);
        
        // Create test directory if it doesn't exist
        const testDir = path.join(sourceDir, '..', 'test');
        await this.ensureDirectoryExists(testDir);
        
        const codeunitId = this.extractCodeunitId(testCode);
        const testFileName = `Cod${codeunitId}.Test${sourceFileName}.al`;
        const testFilePath = path.join(testDir, testFileName);
        
        await fs.writeFile(testFilePath, testCode, 'utf8');
        return vscode.Uri.file(testFilePath);
    }

    async ensureDirectoryExists(dirPath: string): Promise<void> {
        try {
            await fs.access(dirPath);
        } catch {
            await fs.mkdir(dirPath, { recursive: true });
        }
    }

    async fileExists(filePath: string): Promise<boolean> {
        try {
            await fs.access(filePath);
            return true;
        } catch {
            return false;
        }
    }

    async readFileContent(uri: vscode.Uri): Promise<string> {
        const buffer = await fs.readFile(uri.fsPath);
        return buffer.toString('utf8');
    }

    async getALFiles(directory: vscode.Uri): Promise<ALFile[]> {
        const alFiles: ALFile[] = [];
        
        try {
            const items = await fs.readdir(directory.fsPath, { withFileTypes: true });
            
            for (const item of items) {
                if (item.isFile() && item.name.endsWith('.al')) {
                    const fileUri = vscode.Uri.file(path.join(directory.fsPath, item.name));
                    alFiles.push({
                        name: item.name,
                        uri: fileUri
                    });
                } else if (item.isDirectory() && !item.name.startsWith('.')) {
                    // Recursively search subdirectories
                    const subDirUri = vscode.Uri.file(path.join(directory.fsPath, item.name));
                    const subFiles = await this.getALFiles(subDirUri);
                    alFiles.push(...subFiles);
                }
            }
        } catch (error) {
            console.error(`Error reading directory ${directory.fsPath}:`, error);
        }
        
        return alFiles;
    }

    private extractCodeunitId(testCode: string): string {
        const match = testCode.match(/codeunit\s+(\d+)/);
        return match ? match[1] : '59000';
    }

    async findTestFiles(sourceUri: vscode.Uri): Promise<ALFile[]> {
        const sourceDir = path.dirname(sourceUri.fsPath);
        const testDir = path.join(sourceDir, '..', 'test');
        
        try {
            const testDirUri = vscode.Uri.file(testDir);
            return await this.getALFiles(testDirUri);
        } catch {
            return [];
        }
    }

    async createTestSuite(testFiles: ALFile[], suiteName: string): Promise<vscode.Uri> {
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            throw new Error('No workspace folder found');
        }

        const testDir = path.join(workspaceFolder.uri.fsPath, 'test');
        await this.ensureDirectoryExists(testDir);

        const suiteContent = this.generateTestSuiteContent(testFiles, suiteName);
        const suiteFileName = `TestSuite.${suiteName}.al`;
        const suitePath = path.join(testDir, suiteFileName);

        await fs.writeFile(suitePath, suiteContent, 'utf8');
        return vscode.Uri.file(suitePath);
    }

    private generateTestSuiteContent(testFiles: ALFile[], suiteName: string): string {
        const testCodeunits = testFiles.map(file => {
            const codeunitId = this.extractCodeunitIdFromFileName(file.name);
            const codeunitName = path.basename(file.name, '.al');
            return `        Codeunit.Run(Codeunit::"${codeunitName}");`;
        }).join('\n');

        return `/// <summary>
/// Test Suite: ${suiteName}
/// Generated test suite for running multiple test codeunits
/// </summary>
codeunit 59999 "Test Suite ${suiteName}"
{
    Subtype = TestRunner;

    trigger OnRun()
    begin
        // Run all test codeunits in this suite
${testCodeunits}
    end;
}`;
    }

    private extractCodeunitIdFromFileName(fileName: string): string {
        const match = fileName.match(/^Cod(\d+)/);
        return match ? match[1] : '59000';
    }

    async openFileInEditor(uri: vscode.Uri): Promise<void> {
        const document = await vscode.workspace.openTextDocument(uri);
        await vscode.window.showTextDocument(document, { preview: false });
    }

    async validateALSyntax(content: string): Promise<boolean> {
        // Basic AL syntax validation
        const requiredElements = [
            /codeunit\s+\d+/i,
            /Subtype\s*=\s*Test/i
        ];

        return requiredElements.every(pattern => pattern.test(content));
    }
}