import * as vscode from 'vscode';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as path from 'path';
import * as fs from 'fs';

const execAsync = promisify(exec);

export class GitHelper {
    private workspaceFolder: vscode.WorkspaceFolder | undefined;

    constructor() {
        this.workspaceFolder = vscode.workspace.workspaceFolders?.[0];
    }

    private getWorkspacePath(): string {
        if (!this.workspaceFolder) {
            throw new Error('No workspace folder found');
        }
        // Fix: Use .uri.fsPath instead of .fsPath
        return this.workspaceFolder.uri.fsPath;
    }

    async isGitRepository(): Promise<boolean> {
        try {
            const workspacePath = this.getWorkspacePath();
            const gitPath = path.join(workspacePath, '.git');
            return fs.existsSync(gitPath);
        } catch {
            return false;
        }
    }

    async getGitStatus(): Promise<string> {
        try {
            const { stdout } = await execAsync('git status --porcelain', {
                cwd: this.getWorkspacePath()
            });
            return stdout.trim();
        } catch (error) {
            throw new Error(`Failed to get git status: ${error}`);
        }
    }

    async getModifiedFiles(): Promise<string[]> {
        try {
            const status = await this.getGitStatus();
            if (!status) {
                return [];
            }

            return status
                .split('\n')
                .map(line => line.substring(3).trim())
                .filter(file => file.length > 0);
        } catch (error) {
            console.error('Error getting modified files:', error);
            return [];
        }
    }

    async getStagedFiles(): Promise<string[]> {
        try {
            const { stdout } = await execAsync('git diff --cached --name-only', {
                cwd: this.getWorkspacePath()
            });
            return stdout.trim().split('\n').filter(file => file.length > 0);
        } catch (error) {
            console.error('Error getting staged files:', error);
            return [];
        }
    }

    async getCurrentBranch(): Promise<string> {
        try {
            const { stdout } = await execAsync('git branch --show-current', {
                cwd: this.getWorkspacePath()
            });
            return stdout.trim();
        } catch (error) {
            throw new Error(`Failed to get current branch: ${error}`);
        }
    }

    async getLastCommitMessage(): Promise<string> {
        try {
            const { stdout } = await execAsync('git log -1 --pretty=format:"%s"', {
                cwd: this.getWorkspacePath()
            });
            return stdout.trim().replace(/"/g, '');
        } catch (error) {
            throw new Error(`Failed to get last commit message: ${error}`);
        }
    }

    async getDiff(file?: string): Promise<string> {
        try {
            const command = file ? `git diff ${file}` : 'git diff';
            const { stdout } = await execAsync(command, {
                cwd: this.getWorkspacePath()
            });
            return stdout;
        } catch (error) {
            throw new Error(`Failed to get diff: ${error}`);
        }
    }

    async getStagedDiff(): Promise<string> {
        try {
            const { stdout } = await execAsync('git diff --cached', {
                cwd: this.getWorkspacePath()
            });
            return stdout;
        } catch (error) {
            throw new Error(`Failed to get staged diff: ${error}`);
        }
    }

    async addFile(filePath: string): Promise<void> {
        try {
            await execAsync(`git add "${filePath}"`, {
                cwd: this.getWorkspacePath()
            });
        } catch (error) {
            throw new Error(`Failed to add file ${filePath}: ${error}`);
        }
    }

    async addAllFiles(): Promise<void> {
        try {
            await execAsync('git add .', {
                cwd: this.getWorkspacePath()
            });
        } catch (error) {
            throw new Error(`Failed to add all files: ${error}`);
        }
    }

    async commit(message: string): Promise<void> {
        try {
            await execAsync(`git commit -m "${message.replace(/"/g, '\\"')}"`, {
                cwd: this.getWorkspacePath()
            });
        } catch (error) {
            throw new Error(`Failed to commit: ${error}`);
        }
    }

    async push(remote: string = 'origin', branch?: string): Promise<void> {
        try {
            const currentBranch = branch || await this.getCurrentBranch();
            await execAsync(`git push ${remote} ${currentBranch}`, {
                cwd: this.getWorkspacePath()
            });
        } catch (error) {
            throw new Error(`Failed to push: ${error}`);
        }
    }

    async pull(remote: string = 'origin', branch?: string): Promise<void> {
        try {
            const currentBranch = branch || await this.getCurrentBranch();
            await execAsync(`git pull ${remote} ${currentBranch}`, {
                cwd: this.getWorkspacePath()
            });
        } catch (error) {
            throw new Error(`Failed to pull: ${error}`);
        }
    }

    async createBranch(branchName: string, switchTo: boolean = true): Promise<void> {
        try {
            const command = switchTo 
                ? `git checkout -b ${branchName}` 
                : `git branch ${branchName}`;
            
            await execAsync(command, {
                cwd: this.getWorkspacePath()
            });
        } catch (error) {
            throw new Error(`Failed to create branch ${branchName}: ${error}`);
        }
    }

    async switchBranch(branchName: string): Promise<void> {
        try {
            await execAsync(`git checkout ${branchName}`, {
                cwd: this.getWorkspacePath()
            });
        } catch (error) {
            throw new Error(`Failed to switch to branch ${branchName}: ${error}`);
        }
    }

    async getRemoteUrl(): Promise<string> {
        try {
            const { stdout } = await execAsync('git remote get-url origin', {
                cwd: this.getWorkspacePath()
            });
            return stdout.trim();
        } catch (error) {
            throw new Error(`Failed to get remote URL: ${error}`);
        }
    }

    async getFileContent(filePath: string, commit: string = 'HEAD'): Promise<string> {
        try {
            const { stdout } = await execAsync(`git show ${commit}:${filePath}`, {
                cwd: this.getWorkspacePath()
            });
            return stdout;
        } catch (error) {
            throw new Error(`Failed to get file content for ${filePath}: ${error}`);
        }
    }

    async getCommitHistory(maxCount: number = 10): Promise<Array<{hash: string, message: string, author: string, date: string}>> {
        try {
            const { stdout } = await execAsync(`git log --oneline --format="%H|%s|%an|%ad" --date=short -n ${maxCount}`, {
                cwd: this.getWorkspacePath()
            });

            return stdout.trim().split('\n').map(line => {
                const [hash, message, author, date] = line.split('|');
                return { hash, message, author, date };
            });
        } catch (error) {
            throw new Error(`Failed to get commit history: ${error}`);
        }
    }
}