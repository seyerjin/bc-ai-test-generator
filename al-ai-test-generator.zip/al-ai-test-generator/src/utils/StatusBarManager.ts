import * as vscode from 'vscode';

export class StatusBarManager implements vscode.Disposable {
    private statusBarItem: vscode.StatusBarItem;
    private progressTimer: NodeJS.Timeout | undefined;

    constructor() {
        this.statusBarItem = vscode.window.createStatusBarItem(
            vscode.StatusBarAlignment.Right,
            100
        );
        this.statusBarItem.text = '$(beaker) AL Test Gen';
        this.statusBarItem.tooltip = 'AL AI Test Generator - Click to configure';
        this.statusBarItem.command = 'alAiTestGen.configure';
        this.statusBarItem.backgroundColor = undefined;
        this.statusBarItem.show();
    }

    /**
     * Show progress with animated dots and specific message
     * @param message - The progress message to display
     */
    showProgress(message: string): void {
        this.clearProgress();
        let dots = '';
        this.progressTimer = setInterval(() => {
            dots = dots.length >= 3 ? '' : dots + '.';
            this.statusBarItem.text = `$(sync~spin) ${message}${dots}`;
            this.statusBarItem.tooltip = `AL AI Test Generator: ${message}`;
            this.statusBarItem.backgroundColor = undefined;
        }, 500);
    }

    /**
     * Show success message - specifically "Finished" for completion
     * @param message - Success message, defaults to "Finished"
     */
    showSuccess(message: string = 'Finished'): void {
        this.clearProgress();
        this.statusBarItem.text = `$(check) ${message}`;
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.successBackground');
        this.statusBarItem.tooltip = 'Test generation completed successfully!';
        
        // Show for 3 seconds then reset
        setTimeout(() => {
            this.reset();
        }, 3000);
    }

    /**
     * Show error message
     * @param message - Error message to display
     */
    showError(message: string): void {
        this.clearProgress();
        this.statusBarItem.text = `$(error) ${message}`;
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBarItem.tooltip = 'Test generation failed - Click to configure';
        
        // Show for 5 seconds then reset
        setTimeout(() => {
            this.reset();
        }, 5000);
    }

    /**
     * Show warning message
     * @param message - Warning message to display
     */
    showWarning(message: string): void {
        this.clearProgress();
        this.statusBarItem.text = `$(warning) ${message}`;
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
        this.statusBarItem.tooltip = message;
        
        // Show for 4 seconds then reset
        setTimeout(() => {
            this.reset();
        }, 4000);
    }

    /**
     * Show connection successful message
     */
    showConnectionSuccess(): void {
        this.clearProgress();
        this.statusBarItem.text = '$(check) Connection successful';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.successBackground');
        this.statusBarItem.tooltip = 'Claude API connection successful - Ready for testing!';
        
        // Show for 3 seconds then reset
        setTimeout(() => {
            this.reset();
        }, 3000);
    }

    /**
     * Show API key configuration prompt
     */
    showConfigurePrompt(): void {
        this.clearProgress();
        this.statusBarItem.text = '$(key) Configure API Key';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
        this.statusBarItem.tooltip = 'Click to configure your Claude API key';
        this.statusBarItem.command = 'alAiTestGen.configure';
    }

    /**
     * Reset to default state
     */
    private reset(): void {
        this.statusBarItem.text = '$(beaker) AL Test Gen';
        this.statusBarItem.backgroundColor = undefined;
        this.statusBarItem.tooltip = 'AL AI Test Generator - Click to configure';
        this.statusBarItem.command = 'alAiTestGen.configure';
    }

    /**
     * Clear any running progress animation
     */
    private clearProgress(): void {
        if (this.progressTimer) {
            clearInterval(this.progressTimer);
            this.progressTimer = undefined;
        }
    }

    /**
     * Hide the status bar item
     */
    hide(): void {
        this.statusBarItem.hide();
    }

    /**
     * Show the status bar item
     */
    show(): void {
        this.statusBarItem.show();
    }

    /**
     * Dispose of resources
     */
    dispose(): void {
        this.clearProgress();
        this.statusBarItem.dispose();
    }
}