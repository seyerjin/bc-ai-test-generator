import * as vscode from 'vscode';

export interface TestGenerationMetrics {
    timestamp: number;
    sessionId: string;
    fileSize: number;
    fileName: string;
    procedureCount: number;
    generationTimeMs: number;
    testCount: number;
    tokensUsed?: number;
    complexity: string;
    success: boolean;
    errorMessage?: string;
    apiResponseTime?: number;
    cacheHit?: boolean;
}

export interface CodeCoverageMetrics {
    timestamp: number;
    sessionId: string;
    totalLines: number;
    coveredLines: number;
    coveragePercentage: number;
    testFilePath: string;
    sourceFilePath: string;
    testCount: number;
}

export interface AggregatedMetrics {
    totalGenerations: number;
    averageGenerationTime: number;
    successRate: number;
    averageTestsPerFile: number;
    averageCoverage: number;
    averageFileSize: number;
    averageProcedureCount: number;
    timeRange: { start: number; end: number };
    complexityDistribution: Record<string, number>;
    errorFrequency: Record<string, number>;
}

export class TelemetryService {
    private metrics: TestGenerationMetrics[] = [];
    private coverageMetrics: CodeCoverageMetrics[] = [];
    private sessionId: string;
    private sessionStartTime: number;

    constructor(private context: vscode.ExtensionContext) {
        this.sessionId = this.generateSessionId();
        this.sessionStartTime = Date.now();
        this.loadStoredMetrics();
    }

    async recordTestGeneration(metrics: Omit<TestGenerationMetrics, 'timestamp' | 'sessionId'>): Promise<void> {
        const config = vscode.workspace.getConfiguration('alAiTestGen');
        const telemetryEnabled = config.get<boolean>('enableTelemetry', true);
        
        if (!telemetryEnabled) {
            return;
        }

        // Add session and timestamp information
        const enrichedMetrics: TestGenerationMetrics = {
            ...metrics,
            timestamp: Date.now(),
            sessionId: this.sessionId
        };

        this.metrics.push(enrichedMetrics);
        await this.persistMetrics();
        
        console.log('Test generation metrics recorded:', enrichedMetrics);
    }

    async recordCodeCoverage(coverage: Omit<CodeCoverageMetrics, 'timestamp' | 'sessionId'>): Promise<void> {
        const config = vscode.workspace.getConfiguration('alAiTestGen');
        const telemetryEnabled = config.get<boolean>('enableTelemetry', true);
        
        if (!telemetryEnabled) {
            return;
        }

        const enrichedCoverage: CodeCoverageMetrics = {
            ...coverage,
            timestamp: Date.now(),
            sessionId: this.sessionId
        };

        this.coverageMetrics.push(enrichedCoverage);
        await this.persistMetrics();
    }

    getAggregatedMetrics(): AggregatedMetrics {
        if (this.metrics.length === 0) {
            return {
                totalGenerations: 0,
                averageGenerationTime: 0,
                successRate: 0,
                averageTestsPerFile: 0,
                averageCoverage: 0,
                averageFileSize: 0,
                averageProcedureCount: 0,
                timeRange: { start: 0, end: 0 },
                complexityDistribution: {},
                errorFrequency: {}
            };
        }

        const successfulGenerations = this.metrics.filter(m => m.success);
        const totalTime = successfulGenerations.reduce((sum, m) => sum + m.generationTimeMs, 0);
        const totalTests = successfulGenerations.reduce((sum, m) => sum + m.testCount, 0);
        const totalFileSize = successfulGenerations.reduce((sum, m) => sum + m.fileSize, 0);
        const totalProcedures = successfulGenerations.reduce((sum, m) => sum + m.procedureCount, 0);
        const totalCoverage = this.coverageMetrics.reduce((sum, c) => sum + c.coveragePercentage, 0);

        const timestamps = this.metrics.map(m => m.timestamp);

        // Complexity distribution
        const complexityDistribution: Record<string, number> = {};
        this.metrics.forEach(m => {
            complexityDistribution[m.complexity] = (complexityDistribution[m.complexity] || 0) + 1;
        });

        // Error frequency
        const errorFrequency: Record<string, number> = {};
        this.metrics.filter(m => !m.success && m.errorMessage).forEach(m => {
            const errorType = this.categorizeError(m.errorMessage!);
            errorFrequency[errorType] = (errorFrequency[errorType] || 0) + 1;
        });

        return {
            totalGenerations: this.metrics.length,
            averageGenerationTime: totalTime / successfulGenerations.length || 0,
            successRate: (successfulGenerations.length / this.metrics.length) * 100,
            averageTestsPerFile: totalTests / successfulGenerations.length || 0,
            averageCoverage: totalCoverage / this.coverageMetrics.length || 0,
            averageFileSize: totalFileSize / successfulGenerations.length || 0,
            averageProcedureCount: totalProcedures / successfulGenerations.length || 0,
            timeRange: {
                start: Math.min(...timestamps),
                end: Math.max(...timestamps)
            },
            complexityDistribution,
            errorFrequency
        };
    }

    async exportMetricsForResearch(): Promise<string> {
        const aggregated = this.getAggregatedMetrics();
        
        const data = {
            exportInfo: {
                sessionId: this.sessionId,
                exportTimestamp: Date.now(),
                sessionDurationMs: Date.now() - this.sessionStartTime,
                extensionVersion: this.getExtensionVersion(),
                dataPoints: this.metrics.length + this.coverageMetrics.length
            },
            systemInfo: {
                vscodeVersion: vscode.version,
                platform: process.platform,
                nodeVersion: process.version,
                arch: process.arch
            },
            aggregatedMetrics: aggregated,
            rawData: {
                testGenerationMetrics: this.metrics,
                codeCoverageMetrics: this.coverageMetrics
            },
            researchMetrics: {
                // DSR Metrik 1: Erstellungszeit
                averageCreationTimeSeconds: aggregated.averageGenerationTime / 1000,
                
                // DSR Metrik 2: Produktivität
                testsPerHour: this.calculateTestsPerHour(),
                
                // DSR Metrik 3: Personalaufwand (geschätzt)
                estimatedDeveloperTimeReduction: this.estimateTimeReduction(),
                
                // DSR Metrik 4: Code Coverage
                averageCodeCoverage: aggregated.averageCoverage,
                
                // DSR Metrik 5: Fehlererkennungsrate (approximiert)
                successRate: aggregated.successRate,
                
                // Zusätzliche wissenschaftliche Metriken
                complexityHandling: aggregated.complexityDistribution,
                scalabilityMetrics: {
                    averageFileSize: aggregated.averageFileSize,
                    averageProcedureCount: aggregated.averageProcedureCount,
                    performanceByComplexity: this.calculatePerformanceByComplexity()
                }
            }
        };

        return JSON.stringify(data, null, 2);
    }

    async clearMetrics(): Promise<void> {
        const confirm = await vscode.window.showWarningMessage(
            'This will permanently delete all collected telemetry data. This action cannot be undone.',
            { modal: true },
            'Delete All Data',
            'Cancel'
        );

        if (confirm === 'Delete All Data') {
            this.metrics = [];
            this.coverageMetrics = [];
            await this.persistMetrics();
            vscode.window.showInformationMessage('🗑️ All telemetry data cleared successfully');
        }
    }

    async showMetricsSummary(): Promise<void> {
        const aggregated = this.getAggregatedMetrics();
        
        if (aggregated.totalGenerations === 0) {
            vscode.window.showInformationMessage('No metrics data available yet. Generate some tests to see metrics.');
            return;
        }

        const sessionDurationHours = (Date.now() - this.sessionStartTime) / (1000 * 60 * 60);
        
        const summary = `## AL AI Test Generator - Scientific Metrics Summary

### DSR Evaluation Metrics
**Total Test Generations**: ${aggregated.totalGenerations}
**Success Rate**: ${aggregated.successRate.toFixed(1)}%
**Average Generation Time**: ${(aggregated.averageGenerationTime / 1000).toFixed(2)}s
**Average Tests per File**: ${aggregated.averageTestsPerFile.toFixed(1)}
**Average Code Coverage**: ${aggregated.averageCoverage.toFixed(1)}%

### Productivity Analysis
**Tests per Hour**: ${this.calculateTestsPerHour().toFixed(1)}
**Session Duration**: ${sessionDurationHours.toFixed(1)} hours
**Average File Size**: ${Math.round(aggregated.averageFileSize)} bytes
**Average Procedures per File**: ${aggregated.averageProcedureCount.toFixed(1)}

### Complexity Distribution
${Object.entries(aggregated.complexityDistribution)
    .map(([complexity, count]) => `- ${complexity}: ${count} files (${((count/aggregated.totalGenerations)*100).toFixed(1)}%)`)
    .join('\n')}

**Data Collection Period**: ${new Date(aggregated.timeRange.start).toLocaleDateString()} - ${new Date(aggregated.timeRange.end).toLocaleDateString()}

*This data supports the scientific evaluation of AI-powered test generation efficiency for your Master's thesis.*
        `;

        const action = await vscode.window.showInformationMessage(
            summary,
            { modal: true },
            'Export for Research',
            'Clear All Data',
            'Close'
        );

        if (action === 'Export for Research') {
            await this.exportMetricsToFile();
        } else if (action === 'Clear All Data') {
            await this.clearMetrics();
        }
    }

    private async exportMetricsToFile(): Promise<void> {
        try {
            const data = await this.exportMetricsForResearch();
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
            const fileName = `al-ai-test-metrics-${timestamp}.json`;
            
            const uri = await vscode.window.showSaveDialog({
                defaultUri: vscode.Uri.file(fileName),
                filters: {
                    'JSON Research Data': ['json'],
                    'All Files': ['*']
                },
                saveLabel: 'Export Research Data'
            });

            if (uri) {
                await vscode.workspace.fs.writeFile(uri, Buffer.from(data, 'utf8'));
                vscode.window.showInformationMessage(`📊 Research metrics exported to ${uri.fsPath}`);
            }
        } catch (error) {
            console.error('Export error:', error);
            vscode.window.showErrorMessage(`❌ Failed to export metrics: ${error}`);
        }
    }

    private calculateTestsPerHour(): number {
        if (this.metrics.length === 0) return 0;
        
        const sessionDurationHours = (Date.now() - this.sessionStartTime) / (1000 * 60 * 60);
        const totalTests = this.metrics.reduce((sum, m) => sum + (m.success ? m.testCount : 0), 0);
        
        return sessionDurationHours > 0 ? totalTests / sessionDurationHours : 0;
    }

    private estimateTimeReduction(): number {
        // Estimate based on assumption that manual test creation takes 5-10 minutes per test
        const totalGeneratedTests = this.metrics.reduce((sum, m) => sum + (m.success ? m.testCount : 0), 0);
        const averageManualTimePerTest = 7 * 60 * 1000; // 7 minutes in milliseconds
        const totalManualTime = totalGeneratedTests * averageManualTimePerTest;
        const totalAiTime = this.metrics.reduce((sum, m) => sum + (m.success ? m.generationTimeMs : 0), 0);
        
        return totalManualTime > 0 ? ((totalManualTime - totalAiTime) / totalManualTime) * 100 : 0;
    }

    private calculatePerformanceByComplexity(): Record<string, { avgTime: number; avgTests: number; count: number }> {
        const complexityPerf: Record<string, { totalTime: number; totalTests: number; count: number }> = {};
        
        this.metrics.filter(m => m.success).forEach(m => {
            if (!complexityPerf[m.complexity]) {
                complexityPerf[m.complexity] = { totalTime: 0, totalTests: 0, count: 0 };
            }
            if (complexityPerf[m.complexity]) {
                complexityPerf[m.complexity].totalTime += m.generationTimeMs;
                complexityPerf[m.complexity].totalTests += m.testCount;
                complexityPerf[m.complexity].count += 1;
            }
        });

        const result: Record<string, { avgTime: number; avgTests: number; count: number }> = {};
        Object.entries(complexityPerf).forEach(([complexity, data]) => {
            result[complexity] = {
                avgTime: data.totalTime / data.count,
                avgTests: data.totalTests / data.count,
                count: data.count
            };
        });

        return result;
    }

    private categorizeError(errorMessage: string): string {
        if (errorMessage.includes('API key')) return 'Authentication Error';
        if (errorMessage.includes('timeout') || errorMessage.includes('network')) return 'Network Error';
        if (errorMessage.includes('rate limit')) return 'Rate Limit Error';
        if (errorMessage.includes('parse') || errorMessage.includes('syntax')) return 'Parsing Error';
        if (errorMessage.includes('file') || errorMessage.includes('read')) return 'File System Error';
        return 'Unknown Error';
    }

    private async persistMetrics(): Promise<void> {
        try {
            await this.context.globalState.update('testGenerationMetrics', this.metrics);
            await this.context.globalState.update('codeCoverageMetrics', this.coverageMetrics);
            await this.context.globalState.update('sessionStartTime', this.sessionStartTime);
        } catch (error) {
            console.error('Failed to persist metrics:', error);
        }
    }

    private async loadStoredMetrics(): Promise<void> {
        try {
            this.metrics = this.context.globalState.get('testGenerationMetrics', []);
            this.coverageMetrics = this.context.globalState.get('codeCoverageMetrics', []);
            this.sessionStartTime = this.context.globalState.get('sessionStartTime', Date.now());
        } catch (error) {
            console.error('Failed to load stored metrics:', error);
            this.metrics = [];
            this.coverageMetrics = [];
            this.sessionStartTime = Date.now();
        }
    }

    private generateSessionId(): string {
        return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    private getExtensionVersion(): string {
        const extension = vscode.extensions.getExtension('matthias-seyer.al-ai-test-generator');
        return extension?.packageJSON?.version || 'unknown';
    }
}